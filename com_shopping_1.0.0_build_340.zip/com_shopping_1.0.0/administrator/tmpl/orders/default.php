<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
// No direct access
defined('_JEXEC') or die;
use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Layout\LayoutHelper;
use \Joomla\CMS\Language\Text;
use Joomla\CMS\Session\Session;
HTMLHelper::_('bootstrap.tooltip');
HTMLHelper::_('behavior.multiselect');
// Import CSS
$wa =	$this->document->getWebAssetManager();
$wa->useStyle('com_shopping.admin')
	->useScript('com_shopping.admin');
$user		= Factory::getApplication()->getIdentity();
$userId	= $user->get('id');
$listOrder = $this->state->get('list.ordering');
$listDirn	= $this->state->get('list.direction');
$canOrder	= $user->authorise('core.edit.state', 'com_shopping');
$saveOrder = $listOrder == 'a.ordering';
if (!empty($saveOrder))
{
	$saveOrderingUrl = 'index.php?option=com_shopping&task=orders.saveOrderAjax&tmpl=component&' . Session::getFormToken() . '=1';
	HTMLHelper::_('draggablelist.draggable');
}
?>
<form action="<?php echo Route::_('index.php?option=com_shopping&view=orders'); ?>" method="post" name="adminForm" id="adminForm">
	<div class="row">
		<div class="col-md-12">
			<div id="j-main-container" class="j-main-container">
				<?php echo LayoutHelper::render('joomla.searchtools.default', array('view' => $this)); ?>
				<div class="clearfix"></div>
				<table class="table table-striped" id="orderList">
					<thead>
						<tr>
							<th class="w-1 text-center">
								<input type="checkbox" autocomplete="off" class="form-check-input" name="checkall-toggle" value=""
									title="<?php echo Text::_('JGLOBAL_CHECK_ALL'); ?>" onclick="Joomla.checkAll(this)"/>
							</th>
							<th scope="col" class="w-3 d-none d-lg-table-cell" >
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_ID', 'a.id', $listDirn, $listOrder); ?>					
							</th>
							<?php if (isset($this->items[0]->ordering)): ?>
							<th scope="col" class="w-1 text-center d-none d-md-table-cell">
								<?php echo HTMLHelper::_('searchtools.sort', '', 'a.ordering', $listDirn, $listOrder, null, 'asc', 'COM_SHOPPING_ORDERS_ORDERING', 'icon-menu-2'); ?>
							</th>
							<?php endif; ?>
							<th  scope="col" class="w-1 text-center">
								<?php echo HTMLHelper::_('searchtools.sort', 'COM_SHOPPING_ORDERS_STATE', 'a.state', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_TITLE', 'a.title', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_NUMBER', 'a.number', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_ITEMS', 'a.items', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_TOTAL', 'a.total', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_NAME', 'a.name', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_PHONE', 'a.phone', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_EMAIL', 'a.email', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_MOBILE', 'a.mobile', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_PRIVONCE', 'a.privonce', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_CITY', 'a.city', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_POSTAL_CODE', 'a.postal_code', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_ORDER_DATE', 'a.order_date', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_BANK_RFCODE', 'a.bank_rfcode', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_POST_RFCODE', 'a.post_rfcode', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_PAYMENT', 'a.payment', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_USER', 'a.user', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_STATUS', 'a.status', $listDirn, $listOrder); ?>
							</th>
							<th class='left'>
								<?php echo HTMLHelper::_('searchtools.sort',  'COM_SHOPPING_ORDERS_TOKEN', 'a.token', $listDirn, $listOrder); ?>
							</th>
							</tr>
					</thead>
					<tfoot>
						<tr>
							<td colspan="<?php echo isset($this->items[0]) ? count(get_object_vars($this->items[0])) : 10; ?>">
								<?php echo $this->pagination->getListFooter(); ?>
							</td>
						</tr>
					</tfoot>
					<tbody <?php if (!empty($saveOrder)) :?> class="js-draggable" data-url="<?php echo $saveOrderingUrl; ?>" data-direction="<?php echo strtolower($listDirn); ?>" <?php endif; ?>>
						<?php foreach ($this->items as $i => $item) :
							$ordering   = ($listOrder == 'a.ordering');
							$canCreate  = $user->authorise('core.create', 'com_shopping');
							$canEdit    = $user->authorise('core.edit', 'com_shopping');
							$canCheckin = $user->authorise('core.manage', 'com_shopping');
							$canChange  = $user->authorise('core.edit.state', 'com_shopping');
							?>
						<tr class="row<?php echo $i % 2; ?>" data-draggable-group='1' data-transition>
							<td class="text-center">
								<?php echo HTMLHelper::_('grid.id', $i, $item->id); ?>
							</td>
							<td class="d-none d-lg-table-cell">
								<?php echo $item->id; ?>
							</td>
							<?php if (isset($this->items[0]->ordering)) : ?>
							<td class="text-center d-none d-md-table-cell">
								<?php
									$iconClass = '';
									
									if (!$canChange)
									
									{
										$iconClass = ' inactive';
									
									}
									elseif (!$saveOrder)
									
									{
										$iconClass = ' inactive" title="' . Text::_('JORDERINGDISABLED');
									
									}							?>							<span class="sortable-handler<?php echo $iconClass ?>">
								<span class="icon-ellipsis-v" aria-hidden="true"></span>
								</span>
								<?php if ($canChange && $saveOrder) : ?>
								<input type="text" name="order[]" size="5" value="<?php echo $item->ordering; ?>" class="width-20 text-area-order hidden">
								<?php endif; ?>
							</td>
							<?php endif; ?>
							<td class="text-center">
								<?php echo HTMLHelper::_('jgrid.published', $item->state, $i, 'orders.', $canChange, 'cb'); ?>
							</td>
							<td>
								<?php if ($canEdit) : ?>
								<a href="<?php echo Route::_('index.php?option=com_shopping&task=order.edit&id='.(int) $item->id); ?>">
								<?php echo $this->escape($item->title); ?>
								</a>
								<?php else : ?>
								<?php echo $this->escape($item->title); ?>
								<?php endif; ?>
							</td>
							<td>
								<?php echo $item->number; ?>
							</td>
							<td>
								<?php echo $item->items; ?>
							</td>
							<td>
								<?php echo $item->total; ?>
							</td>
							<td>
								<?php if ($canEdit) : ?>
								<a href="<?php echo Route::_('index.php?option=com_shopping&task=order.edit&id='.(int) $item->id); ?>">
								<?php echo $this->escape($item->name); ?>
								</a>
								<?php else : ?>
								<?php echo $this->escape($item->name); ?>
								<?php endif; ?>
							</td>
							<td>
								<?php echo $item->phone; ?>
							</td>
							<td>
								<?php echo $item->email; ?>
							</td>
							<td>
								<?php echo $item->mobile; ?>
							</td>
							<td>
								<?php echo $item->privonce; ?>
							</td>
							<td>
								<?php echo $item->city; ?>
							</td>
							<td>
								<?php echo $item->postal_code; ?>
							</td>
							<td>
								<?php echo $item->order_date; ?>
							</td>
							<td>
								<?php echo $item->bank_rfcode; ?>
							</td>
							<td>
								<?php echo $item->post_rfcode; ?>
							</td>
							<td>
								<?php echo $item->payment; ?>
							</td>
							<td>
								<?php echo $item->user; ?>
							</td>
							<td>
								<?php echo $item->status; ?>
							</td>
							<td>
								<?php echo $item->token; ?>
							</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<input type="hidden" name="task" value=""/>
				<input type="hidden" name="boxchecked" value="0"/>
				<input type="hidden" name="list[fullorder]" value="<?php echo $listOrder; ?> <?php echo $listDirn; ?>"/>
				<?php echo HTMLHelper::_('form.token'); ?>
			</div>
		</div>
	</div>
</form>
