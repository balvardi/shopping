
DROP TABLE IF EXISTS `#__shopping_vendor`;

DROP TABLE IF EXISTS `#__shopping_category`;

DROP TABLE IF EXISTS `#__shopping_product`;

DROP TABLE IF EXISTS `#__shopping_field`;

DROP TABLE IF EXISTS `#__shopping_campaign`;

DROP TABLE IF EXISTS `#__shopping_discount`;

DROP TABLE IF EXISTS `#__shopping_order`;

DROP TABLE IF EXISTS `#__shopping_address`;

DROP TABLE IF EXISTS `#__shopping_province`;

DROP TABLE IF EXISTS `#__shopping_city`;

DROP TABLE IF EXISTS `#__shopping_gateway`;

DROP TABLE IF EXISTS `#__shopping_shipping`;

DROP TABLE IF EXISTS `#__shopping_behavior`;

DROP TABLE IF EXISTS `#__shopping_analysis`;

DROP TABLE IF EXISTS `#__shopping_recommender_visits`;

DROP TABLE IF EXISTS `#__shopping_api_keys`;

DROP TABLE IF EXISTS `#__shopping_notification`;

DROP TABLE IF EXISTS `#__shopping_company`;
