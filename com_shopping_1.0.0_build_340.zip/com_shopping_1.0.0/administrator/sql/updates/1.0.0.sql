
/* Only Addon.ir premium users are allowed to update a component */
