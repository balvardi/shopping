<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	// No direct access
	defined('_JEXEC') or die;
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Joomla\CMS\Session\Session;
	use Joomla\Utilities\ArrayHelper;
?>
<div class="container discount-content">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
	<?php endif;?>
	<div class="text-data">
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_ID'); ?></div>
			<div class="col-md-9"><?php echo $this->item->id; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_STATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->state; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_TITLE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->title; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_CODE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->code; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_START_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->start_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_END_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->end_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_DISCOUNT'); ?></div>
			<div class="col-md-9"><?php echo $this->item->discount; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_NUMBER'); ?></div>
			<div class="col-md-9"><?php echo $this->item->number; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_CREATED_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->created_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_PRODUCTS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->products; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_CATEGORIES'); ?></div>
			<div class="col-md-9"><?php echo $this->item->categories; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_DISCOUNT_MEMBER'); ?></div>
			<div class="col-md-9"><?php echo $this->item->member; ?></div>
		</div>
	</div>
</div>