<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	// No direct access
	defined('_JEXEC') or die;
	
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Shopping\Component\Shopping\Site\Helper\ShoppingHelper;
	
	$wa = $this->document->getWebAssetManager();
	$wa->useScript('keepalive')
		->useScript('form.validate');
	HTMLHelper::_('bootstrap.tooltip');
	
	// Load admin language file
	$lang = Factory::getLanguage();
	$lang->load('com_shopping', JPATH_SITE);
	
	$user	= Factory::getApplication()->getIdentity();
	$canEdit = ShoppingHelper::canUserEdit($this->item, $user);
	
	
	?>
<div class="vendor-edit front-end-edit">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
	<?php endif;?>
	<?php if (!$canEdit) : ?>
	<h3>
		<?php throw new \Exception(Text::_('COM_SHOPPING_ERROR_MESSAGE_NOT_AUTHORISED'), 403); ?>
	</h3>
	<?php else : ?>
	<?php if (!empty($this->item->id)): ?>
	<h1><?php echo Text::sprintf('COM_SHOPPING_EDIT_ITEM_TITLE', $this->item->id); ?></h1>
	<?php else: ?>
	<h1><?php echo Text::_('COM_SHOPPING_ADD_ITEM_TITLE'); ?></h1>
	<?php endif; ?>
	<form id="form-vendor"
		action="<?php echo Route::_('index.php?option=com_shopping&task=vendorform.save'); ?>"
		method="post" class="form-validate form-horizontal" enctype="multipart/form-data">
		<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'vendor')); ?>
		<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'vendor', Text::_('COM_SHOPPING_TAB_VENDOR', true)); ?>
		<?php echo $this->form->renderField('id'); ?>
		<?php echo $this->form->renderField('ordering'); ?>
		<?php echo $this->form->renderField('state'); ?>
		<?php echo $this->form->renderField('title'); ?>
		<?php echo $this->form->renderField('alias'); ?>
		<?php echo $this->form->renderField('phone'); ?>
		<?php echo $this->form->renderField('email'); ?>
		<?php echo $this->form->renderField('privonce'); ?>
		<?php echo $this->form->renderField('city'); ?>
		<?php echo $this->form->renderField('address'); ?>
		<?php echo $this->form->renderField('postal_code'); ?>
		<?php echo $this->form->renderField('user'); ?>
		<?php echo $this->form->renderField('location'); ?>
		<?php echo $this->form->renderField('logo'); ?>
		<?php if (!empty($this->item->logo)) : ?>
		<?php $logoFiles = array(); ?>
		<?php foreach ((array)$this->item->logo as $fileSingle) : ?>
		<?php if (!is_array($fileSingle)) : ?>
		<a href="<?php echo Route::_(Uri::root() . 'images/logo' . DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
		<?php $logoFiles[] = $fileSingle; ?>
		<?php endif; ?>
		<?php endforeach; ?>
		<input type="hidden" name="jform[logo_hidden]" id="jform_logo_hidden" value="<?php echo implode(',', $logoFiles); ?>" />
		<?php endif; ?>
		<?php echo $this->form->renderField('gallery'); ?>
		<?php if (!empty($this->item->gallery)) : ?>
		<?php $galleryFiles = array(); ?>
		<?php foreach ((array)$this->item->gallery as $fileSingle) : ?>
		<?php if (!is_array($fileSingle)) : ?>
		<a href="<?php echo Route::_(Uri::root() . 'images/gallery' . DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
		<?php $galleryFiles[] = $fileSingle; ?>
		<?php endif; ?>
		<?php endforeach; ?>
		<input type="hidden" name="jform[gallery_hidden]" id="jform_gallery_hidden" value="<?php echo implode(',', $galleryFiles); ?>" />
		<?php endif; ?>
		<?php echo HTMLHelper::_('uitab.endTab'); ?>
		<div class="control-group">
			<div class="controls">
				<?php if ($this->canSave): ?>
				<button type="submit" class="validate btn btn-primary">
				<span class="fas fa-check" aria-hidden="true"></span>
				<?php echo Text::_('JSUBMIT'); ?>
				</button>
				<?php endif; ?>
				<a class="btn btn-danger"
					href="<?php echo Route::_('index.php?option=com_shopping&task=vendorform.cancel'); ?>"
					title="<?php echo Text::_('JCANCEL'); ?>">
				<span class="fas fa-times" aria-hidden="true"></span>
				<?php echo Text::_('JCANCEL'); ?>
				</a>
			</div>
		</div>
		<input type="hidden" name="option" value="com_shopping"/>
		<input type="hidden" name="task"
			value="vendorform.save"/>
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
	<?php endif; ?>
</div>
			