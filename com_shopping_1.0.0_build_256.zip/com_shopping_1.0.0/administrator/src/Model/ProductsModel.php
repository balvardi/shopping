<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Shopping\Component\Shopping\Administrator\Helper\ShoppingHelper;
/**
 * Methods supporting a list of Products records.
 *
 * @since	1.0.0
 */
class ProductsModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param	array	$config	An optional associative array of configuration settings.
	*
	* @see		JController
	* @since		1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			
				'id', 'a.id',
				'ordering', 'a.ordering',
				'state', 'a.state',
				'title', 'a.title',
				'alias', 'a.alias',
				'photo', 'a.photo',
				'gallery', 'a.gallery',
				'category', 'a.category',
				'description', 'a.description',
				'price', 'a.price',
				'label', 'a.label',
				'weight', 'a.weight',
				'stock', 'a.stock',
				'discount', 'a.discount',
				'discount_date', 'a.discount_date',
				'video', 'a.video',
				'download', 'a.download',
				'download_link', 'a.download_link',
				'aparat', 'a.aparat',
				'param', 'a.param',
				'hits', 'a.hits',
				'created_date', 'a.created_date',
			);
		}
		parent::__construct($config);
	}
	
	
	
	/**
	* Method to auto-populate the model state.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @param	string	$ordering	Elements order
	* @param	string	$direction	Order direction
	*
	* @return void
	*
	* @throws Exception
	*/
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.created_date", "DESC");
		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);
			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}
	/**
	* Method to get a store id based on model configuration state.
	*
	* This is necessary because the model is used by the component and
	* different modules that might need different sets of data or different
	* ordering requirements.
	*
	* @param	string	$id	A prefix for the store id.
	*
	* @return	string A store id.
	*
	* @since	1.0.0
	*/
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}
	/**
	* Build an SQL query to load the list data.
	*
	* @return	DatabaseQuery
	*
	* @since	1.0.0
	*/
	protected function getListQuery()
	{
		// Create a new query object.
		$db	= $this->getDbo();
		$query = $db->getQuery(true);
		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__shopping_product` AS a');
		
		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}
		
		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.id LIKE ' . $search . '  OR	a.ordering LIKE ' . $search . ' OR	a.state LIKE ' . $search . ' OR	a.title LIKE ' . $search . ' OR	a.alias LIKE ' . $search . ' OR	a.photo LIKE ' . $search . ' OR	a.gallery LIKE ' . $search . ' OR	a.category LIKE ' . $search . ' OR	a.description LIKE ' . $search . ' OR	a.price LIKE ' . $search . ' OR	a.label LIKE ' . $search . ' OR	a.weight LIKE ' . $search . ' OR	a.stock LIKE ' . $search . ' OR	a.discount LIKE ' . $search . ' OR	a.discount_date LIKE ' . $search . ' OR	a.video LIKE ' . $search . ' OR	a.download LIKE ' . $search . ' OR	a.download_link LIKE ' . $search . ' OR	a.aparat LIKE ' . $search . ' OR	a.param LIKE ' . $search . ' OR	a.hits LIKE ' . $search . ' OR	a.created_date LIKE ' . $search . ')');
			}
		}
		
		// Filtering ordering
		$filter_ordering = $this->state->get("filter.ordering");
		if ($filter_ordering !== null && (is_numeric($filter_ordering) || !empty($filter_ordering)))
		{
			$query->where("a.`ordering` = '".$db->escape($filter_ordering)."'");
		}
		
		// Filtering state
		$filter_state = $this->state->get("filter.state");
		if ($filter_state !== null && (is_numeric($filter_state) || !empty($filter_state)))
		{
			$query->where("a.`state` = '".$db->escape($filter_state)."'");
		}
		
		// Filtering title
		$filter_title = $this->state->get("filter.title");
		if ($filter_title !== null && (is_numeric($filter_title) || !empty($filter_title)))
		{
			$query->where("a.`title` = '".$db->escape($filter_title)."'");
		}
		
		// Filtering alias
		$filter_alias = $this->state->get("filter.alias");
		if ($filter_alias !== null && (is_numeric($filter_alias) || !empty($filter_alias)))
		{
			$query->where("a.`alias` = '".$db->escape($filter_alias)."'");
		}
		
		// Filtering photo
		$filter_photo = $this->state->get("filter.photo");
		if ($filter_photo !== null && (is_numeric($filter_photo) || !empty($filter_photo)))
		{
			$query->where("a.`photo` = '".$db->escape($filter_photo)."'");
		}
		
		// Filtering gallery
		$filter_gallery = $this->state->get("filter.gallery");
		if ($filter_gallery !== null && (is_numeric($filter_gallery) || !empty($filter_gallery)))
		{
			$query->where("a.`gallery` = '".$db->escape($filter_gallery)."'");
		}
		
		// Filtering category
		$filter_category = $this->state->get("filter.category");
		if ($filter_category !== null && (is_numeric($filter_category) || !empty($filter_category)))
		{
			$query->where("a.`category` = '".$db->escape($filter_category)."'");
		}
		
		// Filtering description
		$filter_description = $this->state->get("filter.description");
		if ($filter_description !== null && (is_numeric($filter_description) || !empty($filter_description)))
		{
			$query->where("a.`description` = '".$db->escape($filter_description)."'");
		}
		
		// Filtering price
		$filter_price = $this->state->get("filter.price");
		if ($filter_price !== null && (is_numeric($filter_price) || !empty($filter_price)))
		{
			$query->where("a.`price` = '".$db->escape($filter_price)."'");
		}
		
		// Filtering label
		$filter_label = $this->state->get("filter.label");
		if ($filter_label !== null && (is_numeric($filter_label) || !empty($filter_label)))
		{
			$query->where("a.`label` = '".$db->escape($filter_label)."'");
		}
		
		// Filtering weight
		$filter_weight = $this->state->get("filter.weight");
		if ($filter_weight !== null && (is_numeric($filter_weight) || !empty($filter_weight)))
		{
			$query->where("a.`weight` = '".$db->escape($filter_weight)."'");
		}
		
		// Filtering stock
		$filter_stock = $this->state->get("filter.stock");
		if ($filter_stock !== null && (is_numeric($filter_stock) || !empty($filter_stock)))
		{
			$query->where("a.`stock` = '".$db->escape($filter_stock)."'");
		}
		
		// Filtering discount
		$filter_discount = $this->state->get("filter.discount");
		if ($filter_discount !== null && (is_numeric($filter_discount) || !empty($filter_discount)))
		{
			$query->where("a.`discount` = '".$db->escape($filter_discount)."'");
		}
		
		// Filtering discount_date
		$filter_discount_date = $this->state->get("filter.discount_date");
		if ($filter_discount_date !== null && (is_numeric($filter_discount_date) || !empty($filter_discount_date)))
		{
			$query->where("a.`discount_date` = '".$db->escape($filter_discount_date)."'");
		}
		
		// Filtering video
		$filter_video = $this->state->get("filter.video");
		if ($filter_video !== null && (is_numeric($filter_video) || !empty($filter_video)))
		{
			$query->where("a.`video` = '".$db->escape($filter_video)."'");
		}
		
		// Filtering download
		$filter_download = $this->state->get("filter.download");
		if ($filter_download !== null && (is_numeric($filter_download) || !empty($filter_download)))
		{
			$query->where("a.`download` = '".$db->escape($filter_download)."'");
		}
		
		// Filtering download_link
		$filter_download_link = $this->state->get("filter.download_link");
		if ($filter_download_link !== null && (is_numeric($filter_download_link) || !empty($filter_download_link)))
		{
			$query->where("a.`download_link` = '".$db->escape($filter_download_link)."'");
		}
		
		// Filtering aparat
		$filter_aparat = $this->state->get("filter.aparat");
		if ($filter_aparat !== null && (is_numeric($filter_aparat) || !empty($filter_aparat)))
		{
			$query->where("a.`aparat` = '".$db->escape($filter_aparat)."'");
		}
		
		// Filtering param
		$filter_param = $this->state->get("filter.param");
		if ($filter_param !== null && (is_numeric($filter_param) || !empty($filter_param)))
		{
			$query->where("a.`param` = '".$db->escape($filter_param)."'");
		}
		
		// Filtering hits
		$filter_hits = $this->state->get("filter.hits");
		if ($filter_hits !== null && (is_numeric($filter_hits) || !empty($filter_hits)))
		{
			$query->where("a.`hits` = '".$db->escape($filter_hits)."'");
		}
		
		// Filtering created_date
		$filter_created_date = $this->state->get("filter.created_date");
		if ($filter_created_date !== null && (is_numeric($filter_created_date) || !empty($filter_created_date)))
		{
			$query->where("a.`created_date` = '".$db->escape($filter_created_date)."'");
		}
		
		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering', "a.created_date");
		$orderDirn = $this->state->get('list.direction', "DESC");
		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		return $query;
	}
	/**
	* Get an array of data items
	*
	* @return mixed Array of data items on success, false on failure.
	*/
	public function getItems()
	{
		$items = parent::getItems();
		foreach ($items as $oneItem)
		{
		}
		return $items;
	}
}
	