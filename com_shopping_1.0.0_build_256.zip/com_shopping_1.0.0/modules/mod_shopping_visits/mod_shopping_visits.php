<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	defined('_JEXEC') or die;
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Joomla\CMS\Layout\LayoutHelper;
	use \Joomla\CMS\Session\Session;
	$lang						= Factory::getLanguage();
	$extension			 = 'com_shopping';
	$base_dir			= JPATH_SITE;
	$language_tag		 = 'fa-IR';
	$reload				 = true;
	$lang->load($extension, $base_dir, $language_tag, $reload);	
	$doc 					= Factory::getDocument();
	$db 					= Factory::getDBO();
	$slogan 				= $params->get("slogan");
	$description 		= $params->get("description");
	$ordering 			= $params->get("ordering");
	$sorting 			= $params->get("sorting");
	$id 			= $params->get("id");
	$user_id 			= $params->get("user_id");
	$page_url 			= $params->get("page_url");
	$visit_time 			= $params->get("visit_time");
	$view_type 			= $params->get("view_type");
	$viewtype 			= $params->get("viewtype");
	$count 				= $params->get("count","6");
	$desktop_inpage		= $params->get("desktop_inpage");
	$mobile_inpage 		= $params->get("mobile_inpage");
	$position	 		= $params->get("position","right");
	$itemid				= $params->get("itemid");
	$direction 			= $document->direction;
	if($direction=='ltr'):
		$left		= 'left';
		$right		= 'right';
	else:
		$left		= 'right';
		$right		= 'left';
	endif;
	$database 		= JFactory::getDBO();
	
	$query = "SELECT * FROM #__shopping_recommender_visits WHERE `state`='1' ORDER BY $ordering $sorting LIMIT $count";
	//echo $query;
	$db->setQuery($query);
	$list = $db->loadObjectList();
require JModuleHelper::getLayoutPath('mod_shopping_visits', $params->get('layout', 'default'));
			