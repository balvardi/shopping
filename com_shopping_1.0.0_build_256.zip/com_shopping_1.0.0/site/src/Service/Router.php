<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Site\Service;
// No direct access
defined('_JEXEC') or die;
use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Categories\Categories;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Categories\CategoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\CMS\Component\ComponentHelper;
/**
 * Class ShoppingRouter
 *
 */
class Router extends RouterView
{
	private $noIDs;
	/**
	* The category factory
	*
	* @var	CategoryFactoryInterface
	*
	* @since	1.0.0
	*/
	private $categoryFactory;
	/**
	* The category cache
	*
	* @var	array
	*
	* @since	1.0.0
	*/
	private $categoryCache = [];
	public function __construct(SiteApplication $app, AbstractMenu $menu, CategoryFactoryInterface $categoryFactory, DatabaseInterface $db)
	{
		$params = ComponentHelper::getParams('com_shopping');
		$this->noIDs = (bool) $params->get('sef_ids');
		$this->categoryFactory = $categoryFactory;
		
		$categories = new RouterViewConfiguration('categories');
		$categories->setKey('category')->setNestable();
		$this->registerView($categories);
		$ccCategory = new RouterViewConfiguration('category');
		$ccCategory->setKey('id')->setParent($categories, 'category');
		$this->registerView($ccCategory);
		$categoryform = new RouterViewConfiguration('categoryform');
		$categoryform->setKey('id');
		$this->registerView($categoryform);
		$products = new RouterViewConfiguration('products');
		$products->setKey('category')->setNestable();
		$this->registerView($products);
		$ccProduct = new RouterViewConfiguration('product');
		$ccProduct->setKey('id')->setParent($products, 'category');
		$this->registerView($ccProduct);
		$productform = new RouterViewConfiguration('productform');
		$productform->setKey('id');
		$this->registerView($productform);
		$fields = new RouterViewConfiguration('fields');
		$fields->setKey('category')->setNestable();
		$this->registerView($fields);
		$ccField = new RouterViewConfiguration('field');
		$ccField->setKey('id')->setParent($fields, 'category');
		$this->registerView($ccField);
		$fieldform = new RouterViewConfiguration('fieldform');
		$fieldform->setKey('id');
		$this->registerView($fieldform);
		$campaigns = new RouterViewConfiguration('campaigns');
		$campaigns->setKey('category')->setNestable();
		$this->registerView($campaigns);
		$ccCampaign = new RouterViewConfiguration('campaign');
		$ccCampaign->setKey('id')->setParent($campaigns, 'category');
		$this->registerView($ccCampaign);
		$campaignform = new RouterViewConfiguration('campaignform');
		$campaignform->setKey('id');
		$this->registerView($campaignform);
		$orders = new RouterViewConfiguration('orders');
		$orders->setKey('category')->setNestable();
		$this->registerView($orders);
		$ccOrder = new RouterViewConfiguration('order');
		$ccOrder->setKey('id')->setParent($orders, 'category');
		$this->registerView($ccOrder);
		$orderform = new RouterViewConfiguration('orderform');
		$orderform->setKey('id');
		$this->registerView($orderform);
		$addresses = new RouterViewConfiguration('addresses');
		$addresses->setKey('category')->setNestable();
		$this->registerView($addresses);
		$ccAddresse = new RouterViewConfiguration('addresse');
		$ccAddresse->setKey('id')->setParent($addresses, 'category');
		$this->registerView($ccAddresse);
		$addresseform = new RouterViewConfiguration('addresseform');
		$addresseform->setKey('id');
		$this->registerView($addresseform);
		$provinces = new RouterViewConfiguration('provinces');
		$provinces->setKey('category')->setNestable();
		$this->registerView($provinces);
		$ccProvince = new RouterViewConfiguration('province');
		$ccProvince->setKey('id')->setParent($provinces, 'category');
		$this->registerView($ccProvince);
		$provinceform = new RouterViewConfiguration('provinceform');
		$provinceform->setKey('id');
		$this->registerView($provinceform);
		$cities = new RouterViewConfiguration('cities');
		$cities->setKey('category')->setNestable();
		$this->registerView($cities);
		$ccCity = new RouterViewConfiguration('city');
		$ccCity->setKey('id')->setParent($cities, 'category');
		$this->registerView($ccCity);
		$cityform = new RouterViewConfiguration('cityform');
		$cityform->setKey('id');
		$this->registerView($cityform);
		$behaviors = new RouterViewConfiguration('behaviors');
		$behaviors->setKey('category')->setNestable();
		$this->registerView($behaviors);
		$ccBehavior = new RouterViewConfiguration('behavior');
		$ccBehavior->setKey('id')->setParent($behaviors, 'category');
		$this->registerView($ccBehavior);
		$behaviorform = new RouterViewConfiguration('behaviorform');
		$behaviorform->setKey('id');
		$this->registerView($behaviorform);
		$analyses = new RouterViewConfiguration('analyses');
		$analyses->setKey('category')->setNestable();
		$this->registerView($analyses);
		$ccAnalysis = new RouterViewConfiguration('analysis');
		$ccAnalysis->setKey('id')->setParent($analyses, 'category');
		$this->registerView($ccAnalysis);
		$analysisform = new RouterViewConfiguration('analysisform');
		$analysisform->setKey('id');
		$this->registerView($analysisform);
		$visits = new RouterViewConfiguration('visits');
		$visits->setKey('category')->setNestable();
		$this->registerView($visits);
		$ccVisit = new RouterViewConfiguration('visit');
		$ccVisit->setKey('id')->setParent($visits, 'category');
		$this->registerView($ccVisit);
		$visitform = new RouterViewConfiguration('visitform');
		$visitform->setKey('id');
		$this->registerView($visitform);
		$cart = new RouterViewConfiguration('cart');
		$this->registerView($cart);
		
		$dashboard = new RouterViewConfiguration('dashboard');
		$this->registerView($dashboard);
		
		$login = new RouterViewConfiguration('login');
		$this->registerView($login);
		
		$update = new RouterViewConfiguration('update');
		$this->registerView($update);
		
		$featuread = new RouterViewConfiguration('featuread');
		$this->registerView($featuread);
		
		$setting = new RouterViewConfiguration('setting');
		$this->registerView($setting);
		
		$profile = new RouterViewConfiguration('profile');
		$this->registerView($profile);
		
		$search = new RouterViewConfiguration('search');
		$this->registerView($search);
		
		$import = new RouterViewConfiguration('import');
		$this->registerView($import);
		
		$export = new RouterViewConfiguration('export');
		$this->registerView($export);
		
		$download = new RouterViewConfiguration('download');
		$this->registerView($download);
		
		$checkout = new RouterViewConfiguration('checkout');
		$this->registerView($checkout);
		
		parent::__construct($app, $menu);
		$this->attachRule(new MenuRules($this));
		$this->attachRule(new StandardRules($this));
		$this->attachRule(new NomenuRules($this));
	}
	
			/**
			* Method to get the segment(s) for a category
			*
			* @param	string	$id	ID of the category to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getCategoriesSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an category
		*
		* @param	string	$id	ID of the category to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getCategorySegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an categoryform
			*
			* @param	string	$id	ID of the categoryform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getCategoryformSegment($id, $query)
			{
				return $this->getCategorySegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getCategorysId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an category
		*
		* @param	string	$segment	Segment of the category to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getCategoryId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an categoryform
			*
			* @param	string	$segment	Segment of the categoryform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getCategoryformId($segment, $query)
			{
				return $this->getCategoryId($segment, $query);
			}
			public function getProductsSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an product
		*
		* @param	string	$id	ID of the product to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getProductSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an productform
			*
			* @param	string	$id	ID of the productform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getProductformSegment($id, $query)
			{
				return $this->getProductSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getProductsId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an product
		*
		* @param	string	$segment	Segment of the product to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getProductId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an productform
			*
			* @param	string	$segment	Segment of the productform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getProductformId($segment, $query)
			{
				return $this->getProductId($segment, $query);
			}
			public function getFieldsSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an field
		*
		* @param	string	$id	ID of the field to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getFieldSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an fieldform
			*
			* @param	string	$id	ID of the fieldform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getFieldformSegment($id, $query)
			{
				return $this->getFieldSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getFieldsId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an field
		*
		* @param	string	$segment	Segment of the field to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getFieldId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an fieldform
			*
			* @param	string	$segment	Segment of the fieldform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getFieldformId($segment, $query)
			{
				return $this->getFieldId($segment, $query);
			}
			public function getCampaignsSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an campaign
		*
		* @param	string	$id	ID of the campaign to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getCampaignSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an campaignform
			*
			* @param	string	$id	ID of the campaignform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getCampaignformSegment($id, $query)
			{
				return $this->getCampaignSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getCampaignsId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an campaign
		*
		* @param	string	$segment	Segment of the campaign to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getCampaignId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an campaignform
			*
			* @param	string	$segment	Segment of the campaignform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getCampaignformId($segment, $query)
			{
				return $this->getCampaignId($segment, $query);
			}
			public function getOrdersSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an order
		*
		* @param	string	$id	ID of the order to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getOrderSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an orderform
			*
			* @param	string	$id	ID of the orderform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getOrderformSegment($id, $query)
			{
				return $this->getOrderSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getOrdersId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an order
		*
		* @param	string	$segment	Segment of the order to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getOrderId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an orderform
			*
			* @param	string	$segment	Segment of the orderform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getOrderformId($segment, $query)
			{
				return $this->getOrderId($segment, $query);
			}
			public function getAddressesSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an addresse
		*
		* @param	string	$id	ID of the addresse to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getAddresseSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an addresseform
			*
			* @param	string	$id	ID of the addresseform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getAddresseformSegment($id, $query)
			{
				return $this->getAddresseSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getAddressesId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an addresse
		*
		* @param	string	$segment	Segment of the addresse to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getAddresseId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an addresseform
			*
			* @param	string	$segment	Segment of the addresseform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getAddresseformId($segment, $query)
			{
				return $this->getAddresseId($segment, $query);
			}
			public function getProvincesSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an province
		*
		* @param	string	$id	ID of the province to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getProvinceSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an provinceform
			*
			* @param	string	$id	ID of the provinceform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getProvinceformSegment($id, $query)
			{
				return $this->getProvinceSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getProvincesId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an province
		*
		* @param	string	$segment	Segment of the province to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getProvinceId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an provinceform
			*
			* @param	string	$segment	Segment of the provinceform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getProvinceformId($segment, $query)
			{
				return $this->getProvinceId($segment, $query);
			}
			public function getCitiesSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an city
		*
		* @param	string	$id	ID of the city to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getCitySegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an cityform
			*
			* @param	string	$id	ID of the cityform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getCityformSegment($id, $query)
			{
				return $this->getCitySegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getCitysId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an city
		*
		* @param	string	$segment	Segment of the city to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getCityId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an cityform
			*
			* @param	string	$segment	Segment of the cityform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getCityformId($segment, $query)
			{
				return $this->getCityId($segment, $query);
			}
			public function getBehaviorsSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an behavior
		*
		* @param	string	$id	ID of the behavior to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getBehaviorSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an behaviorform
			*
			* @param	string	$id	ID of the behaviorform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getBehaviorformSegment($id, $query)
			{
				return $this->getBehaviorSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getBehaviorsId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an behavior
		*
		* @param	string	$segment	Segment of the behavior to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getBehaviorId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an behaviorform
			*
			* @param	string	$segment	Segment of the behaviorform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getBehaviorformId($segment, $query)
			{
				return $this->getBehaviorId($segment, $query);
			}
			public function getAnalysesSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an analysis
		*
		* @param	string	$id	ID of the analysis to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getAnalysisSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an analysisform
			*
			* @param	string	$id	ID of the analysisform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getAnalysisformSegment($id, $query)
			{
				return $this->getAnalysisSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getAnalysissId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an analysis
		*
		* @param	string	$segment	Segment of the analysis to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getAnalysisId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an analysisform
			*
			* @param	string	$segment	Segment of the analysisform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getAnalysisformId($segment, $query)
			{
				return $this->getAnalysisId($segment, $query);
			}
			public function getVisitsSegment($id, $query)
			{
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category)
				{
					$path = array_reverse($category->getPath(), true);
					$path[0] = '1:root';
					if ($this->noIDs)
					{
						foreach ($path as &$segment)
						{
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
			}
		/**
		* Method to get the segment(s) for an visit
		*
		* @param	string	$id	ID of the visit to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
		*/
		public function getVisitSegment($id, $query)
		{
			return array((int) $id => $id);
		}
			/**
			* Method to get the segment(s) for an visitform
			*
			* @param	string	$id	ID of the visitform to retrieve the segments for
			* @param	array	$query	The request that is built right now
			*
			* @return	array|string	The segments of this item
			*/
			public function getVisitformSegment($id, $query)
			{
				return $this->getVisitSegment($id, $query);
			}
	
			/**
			* Method to get the id for a category
			*
			* @param	string	$segment	Segment to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getVisitsId($segment, $query)
			{
				if (isset($query['category']))
				{
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category)
					{
						foreach ($category->getChildren() as $child)
						{
							if ($this->noIDs)
							{
								if ($child->alias == $segment)
								{
									return $child->id;
								}
							}
							else
							{
								if ($child->id == (int) $segment)
								{
									return $child->id;
								}
							}
						}
					}
				}
				return false;
			}
		/**
		* Method to get the segment(s) for an visit
		*
		* @param	string	$segment	Segment of the visit to retrieve the ID for
		* @param	array	$query	The request that is parsed right now
		*
		* @return	mixed	The id of this item or false
		*/
		public function getVisitId($segment, $query)
		{
			return (int) $segment;
		}
			/**
			* Method to get the segment(s) for an visitform
			*
			* @param	string	$segment	Segment of the visitform to retrieve the ID for
			* @param	array	$query	The request that is parsed right now
			*
			* @return	mixed	The id of this item or false
			*/
			public function getVisitformId($segment, $query)
			{
				return $this->getVisitId($segment, $query);
			}
	/**
	* Method to get categories from cache
	*
	* @param	array	$options	The options for retrieving categories
	*
	* @return	CategoryInterface	The object containing categories
	*
	* @since	1.0.0
	*/
	private function getCategories(array $options = []): CategoryInterface
	{
		$key = serialize($options);
		if (!isset($this->categoryCache[$key]))
		{
			$this->categoryCache[$key] = $this->categoryFactory->createCategory($options);
		}
		return $this->categoryCache[$key];
	}
}
