<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	// No direct access
	defined('_JEXEC') or die;
	
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Shopping\Component\Shopping\Site\Helper\ShoppingHelper;
	
	$wa = $this->document->getWebAssetManager();
	$wa->useScript('keepalive')
		->useScript('form.validate');
	HTMLHelper::_('bootstrap.tooltip');
	
	// Load admin language file
	$lang = Factory::getLanguage();
	$lang->load('com_shopping', JPATH_SITE);
	
	$user	= Factory::getApplication()->getIdentity();
	$canEdit = ShoppingHelper::canUserEdit($this->item, $user);
	
	
	?>
<div class="product-edit front-end-edit">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
	<?php endif;?>
	<?php if (!$canEdit) : ?>
	<h3>
		<?php throw new \Exception(Text::_('COM_SHOPPING_ERROR_MESSAGE_NOT_AUTHORISED'), 403); ?>
	</h3>
	<?php else : ?>
	<?php if (!empty($this->item->id)): ?>
	<h1><?php echo Text::sprintf('COM_SHOPPING_EDIT_ITEM_TITLE', $this->item->id); ?></h1>
	<?php else: ?>
	<h1><?php echo Text::_('COM_SHOPPING_ADD_ITEM_TITLE'); ?></h1>
	<?php endif; ?>
	<form id="form-product"
		action="<?php echo Route::_('index.php?option=com_shopping&task=productform.save'); ?>"
		method="post" class="form-validate form-horizontal" enctype="multipart/form-data">
		<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'product')); ?>
		<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'product', Text::_('COM_SHOPPING_TAB_PRODUCT', true)); ?>
		<?php echo $this->form->renderField('id'); ?>
		<?php echo $this->form->renderField('ordering'); ?>
		<?php echo $this->form->renderField('state'); ?>
		<?php echo $this->form->renderField('title'); ?>
		<?php echo $this->form->renderField('alias'); ?>
		<?php echo $this->form->renderField('photo'); ?>
		<?php if (!empty($this->item->photo)) : ?>
		<?php $photoFiles = array(); ?>
		<?php foreach ((array)$this->item->photo as $fileSingle) : ?>
		<?php if (!is_array($fileSingle)) : ?>
		<a href="<?php echo Route::_(Uri::root() . 'images/photo' . DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
		<?php $photoFiles[] = $fileSingle; ?>
		<?php endif; ?>
		<?php endforeach; ?>
		<input type="hidden" name="jform[photo_hidden]" id="jform_photo_hidden" value="<?php echo implode(',', $photoFiles); ?>" />
		<?php endif; ?>
		<?php echo $this->form->renderField('gallery'); ?>
		<?php if (!empty($this->item->gallery)) : ?>
		<?php $galleryFiles = array(); ?>
		<?php foreach ((array)$this->item->gallery as $fileSingle) : ?>
		<?php if (!is_array($fileSingle)) : ?>
		<a href="<?php echo Route::_(Uri::root() . 'images/gallery' . DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
		<?php $galleryFiles[] = $fileSingle; ?>
		<?php endif; ?>
		<?php endforeach; ?>
		<input type="hidden" name="jform[gallery_hidden]" id="jform_gallery_hidden" value="<?php echo implode(',', $galleryFiles); ?>" />
		<?php endif; ?>
		<?php echo $this->form->renderField('category'); ?>
		<?php echo $this->form->renderField('description'); ?>
		<?php echo $this->form->renderField('price'); ?>
		<?php echo $this->form->renderField('label'); ?>
		<?php echo $this->form->renderField('weight'); ?>
		<?php echo $this->form->renderField('stock'); ?>
		<?php echo $this->form->renderField('discount'); ?>
		<?php echo $this->form->renderField('discount_date'); ?>
		<?php echo $this->form->renderField('video'); ?>
		<?php echo $this->form->renderField('download'); ?>
		<?php echo $this->form->renderField('download_link'); ?>
		<?php echo $this->form->renderField('aparat'); ?>
		<?php echo $this->form->renderField('param'); ?>
		<?php echo $this->form->renderField('hits'); ?>
		<?php echo $this->form->renderField('created_date'); ?>
		<?php echo HTMLHelper::_('uitab.endTab'); ?>
		<div class="control-group">
			<div class="controls">
				<?php if ($this->canSave): ?>
				<button type="submit" class="validate btn btn-primary">
				<span class="fas fa-check" aria-hidden="true"></span>
				<?php echo Text::_('JSUBMIT'); ?>
				</button>
				<?php endif; ?>
				<a class="btn btn-danger"
					href="<?php echo Route::_('index.php?option=com_shopping&task=productform.cancel'); ?>"
					title="<?php echo Text::_('JCANCEL'); ?>">
				<span class="fas fa-times" aria-hidden="true"></span>
				<?php echo Text::_('JCANCEL'); ?>
				</a>
			</div>
		</div>
		<input type="hidden" name="option" value="com_shopping"/>
		<input type="hidden" name="task"
			value="productform.save"/>
		<?php echo HTMLHelper::_('form.token'); ?>
	</form>
	<?php endif; ?>
</div>
			