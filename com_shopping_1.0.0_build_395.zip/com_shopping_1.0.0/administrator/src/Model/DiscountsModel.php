<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Shopping\Component\Shopping\Administrator\Helper\ShoppingHelper;
/**
 * Methods supporting a list of Discounts records.
 *
 * @since	1.0.0
 */
class DiscountsModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param	array	$config	An optional associative array of configuration settings.
	*
	* @see		JController
	* @since		1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			
				'id', 'a.id',
				'state', 'a.state',
				'title', 'a.title',
				'code', 'a.code',
				'start_date', 'a.start_date',
				'end_date', 'a.end_date',
				'discount', 'a.discount',
				'number', 'a.number',
				'created_date', 'a.created_date',
				'products', 'a.products',
				'categories', 'a.categories',
				'member', 'a.member',
			);
		}
		parent::__construct($config);
	}
	
	
	
	/**
	* Method to auto-populate the model state.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @param	string	$ordering	Elements order
	* @param	string	$direction	Order direction
	*
	* @return void
	*
	* @throws Exception
	*/
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "DESC");
		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);
			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}
	/**
	* Method to get a store id based on model configuration state.
	*
	* This is necessary because the model is used by the component and
	* different modules that might need different sets of data or different
	* ordering requirements.
	*
	* @param	string	$id	A prefix for the store id.
	*
	* @return	string A store id.
	*
	* @since	1.0.0
	*/
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}
	/**
	* Build an SQL query to load the list data.
	*
	* @return	DatabaseQuery
	*
	* @since	1.0.0
	*/
	protected function getListQuery()
	{
		// Create a new query object.
		$db	= $this->getDbo();
		$query = $db->getQuery(true);
		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__shopping_discount` AS a');
		
		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}
		
		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.id LIKE ' . $search . '  OR	a.state LIKE ' . $search . ' OR	a.title LIKE ' . $search . ' OR	a.code LIKE ' . $search . ' OR	a.start_date LIKE ' . $search . ' OR	a.end_date LIKE ' . $search . ' OR	a.discount LIKE ' . $search . ' OR	a.number LIKE ' . $search . ' OR	a.created_date LIKE ' . $search . ' OR	a.products LIKE ' . $search . ' OR	a.categories LIKE ' . $search . ' OR	a.member LIKE ' . $search . ')');
			}
		}
		
		// Filtering state
		$filter_state = $this->state->get("filter.state");
		if ($filter_state !== null && (is_numeric($filter_state) || !empty($filter_state)))
		{
			$query->where("a.`state` = '".$db->escape($filter_state)."'");
		}
		
		// Filtering title
		$filter_title = $this->state->get("filter.title");
		if ($filter_title !== null && (is_numeric($filter_title) || !empty($filter_title)))
		{
			$query->where("a.`title` = '".$db->escape($filter_title)."'");
		}
		
		// Filtering code
		$filter_code = $this->state->get("filter.code");
		if ($filter_code !== null && (is_numeric($filter_code) || !empty($filter_code)))
		{
			$query->where("a.`code` = '".$db->escape($filter_code)."'");
		}
		
		// Filtering start_date
		$filter_start_date = $this->state->get("filter.start_date");
		if ($filter_start_date !== null && (is_numeric($filter_start_date) || !empty($filter_start_date)))
		{
			$query->where("a.`start_date` = '".$db->escape($filter_start_date)."'");
		}
		
		// Filtering end_date
		$filter_end_date = $this->state->get("filter.end_date");
		if ($filter_end_date !== null && (is_numeric($filter_end_date) || !empty($filter_end_date)))
		{
			$query->where("a.`end_date` = '".$db->escape($filter_end_date)."'");
		}
		
		// Filtering discount
		$filter_discount = $this->state->get("filter.discount");
		if ($filter_discount !== null && (is_numeric($filter_discount) || !empty($filter_discount)))
		{
			$query->where("a.`discount` = '".$db->escape($filter_discount)."'");
		}
		
		// Filtering number
		$filter_number = $this->state->get("filter.number");
		if ($filter_number !== null && (is_numeric($filter_number) || !empty($filter_number)))
		{
			$query->where("a.`number` = '".$db->escape($filter_number)."'");
		}
		
		// Filtering created_date
		$filter_created_date = $this->state->get("filter.created_date");
		if ($filter_created_date !== null && (is_numeric($filter_created_date) || !empty($filter_created_date)))
		{
			$query->where("a.`created_date` = '".$db->escape($filter_created_date)."'");
		}
		
		// Filtering products
		$filter_products = $this->state->get("filter.products");
		if ($filter_products !== null && (is_numeric($filter_products) || !empty($filter_products)))
		{
			$query->where("a.`products` = '".$db->escape($filter_products)."'");
		}
		
		// Filtering categories
		$filter_categories = $this->state->get("filter.categories");
		if ($filter_categories !== null && (is_numeric($filter_categories) || !empty($filter_categories)))
		{
			$query->where("a.`categories` = '".$db->escape($filter_categories)."'");
		}
		
		// Filtering member
		$filter_member = $this->state->get("filter.member");
		if ($filter_member !== null && (is_numeric($filter_member) || !empty($filter_member)))
		{
			$query->where("a.`member` = '".$db->escape($filter_member)."'");
		}
		
		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "DESC");
		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		return $query;
	}
	/**
	* Get an array of data items
	*
	* @return mixed Array of data items on success, false on failure.
	*/
	public function getItems()
	{
		$items = parent::getItems();
		foreach ($items as $oneItem)
		{
		}
		return $items;
	}
}
	