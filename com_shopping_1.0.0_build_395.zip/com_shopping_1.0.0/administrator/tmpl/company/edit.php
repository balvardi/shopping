<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
// No direct access
defined('_JEXEC') or die;
use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');
HTMLHelper::_('bootstrap.tooltip');
?>
<form action="<?php echo Route::_('index.php?option=com_shopping&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="company-form" class="form-validate form-horizontal">
	<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'company')); ?>
	<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'company', Text::_('COM_SHOPPING_TAB_COMPANY', true)); ?>
	<div class="row-fluid">
		<div class="col-md-12 form-horizontal">
			<fieldset class="adminform">
				<?php echo $this->form->renderField('id'); ?>
				<?php echo $this->form->renderField('ordering'); ?>
				<?php echo $this->form->renderField('state'); ?>
				<?php echo $this->form->renderField('title'); ?>
				<?php echo $this->form->renderField('alias'); ?>
				<?php echo $this->form->renderField('phone'); ?>
				<?php echo $this->form->renderField('email'); ?>
				<?php echo $this->form->renderField('privonce'); ?>
				<?php echo $this->form->renderField('city'); ?>
				<?php echo $this->form->renderField('address'); ?>
				<?php echo $this->form->renderField('postal_code'); ?>
				<?php echo $this->form->renderField('user'); ?>
				<?php echo $this->form->renderField('location'); ?>
				<?php echo $this->form->renderField('logo'); ?>
				<?php if (!empty($this->item->logo)) : ?>
					<?php $logoFiles = array(); ?>
					<?php foreach ((array)$this->item->logo as $fileSingle) : ?>
						<?php if (!is_array($fileSingle)) : ?>
							<a href="<?php echo Route::_(Uri::root() . 'images/logo'. DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
							<?php $logoFiles[] = $fileSingle; ?>
						<?php endif; ?>
					<?php endforeach; ?>
					<input type="hidden" name="jform[logo_hidden]" id="jform_logo_hidden" value="<?php echo implode(',', $logoFiles); ?>" />
				<?php endif; ?>
				<?php echo $this->form->renderField('gallery'); ?>
				<?php if (!empty($this->item->gallery)) : ?>
					<?php $galleryFiles = array(); ?>
					<?php foreach ((array)$this->item->gallery as $fileSingle) : ?>
						<?php if (!is_array($fileSingle)) : ?>
							<a href="<?php echo Route::_(Uri::root() . 'images/gallery'. DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
							<?php $galleryFiles[] = $fileSingle; ?>
						<?php endif; ?>
					<?php endforeach; ?>
					<input type="hidden" name="jform[gallery_hidden]" id="jform_gallery_hidden" value="<?php echo implode(',', $galleryFiles); ?>" />
				<?php endif; ?>
			</fieldset>
		</div>
	</div>
	<?php echo HTMLHelper::_('uitab.endTab'); ?>
	<?php echo HTMLHelper::_('uitab.endTabSet'); ?>
	<input type="hidden" name="task" value=""/>
	<?php echo HTMLHelper::_('form.token'); ?>
</form>
		