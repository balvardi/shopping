<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Shopping\Component\Shopping\Administrator\Helper\ShoppingHelper;
/**
 * Methods supporting a list of Orders records.
 *
 * @since	1.0.0
 */
class OrdersModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param	array	$config	An optional associative array of configuration settings.
	*
	* @see		JController
	* @since		1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			
				'id', 'a.id',
				'ordering', 'a.ordering',
				'state', 'a.state',
				'title', 'a.title',
				'number', 'a.number',
				'items', 'a.items',
				'total', 'a.total',
				'name', 'a.name',
				'phone', 'a.phone',
				'email', 'a.email',
				'mobile', 'a.mobile',
				'privonce', 'a.privonce',
				'city', 'a.city',
				'postal_code', 'a.postal_code',
				'order_date', 'a.order_date',
				'bank_rfcode', 'a.bank_rfcode',
				'post_rfcode', 'a.post_rfcode',
				'payment', 'a.payment',
				'created_by', 'a.created_by',
				'status', 'a.status',
				'token', 'a.token',
			);
		}
		parent::__construct($config);
	}
	
	
	
	/**
	* Method to auto-populate the model state.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @param	string	$ordering	Elements order
	* @param	string	$direction	Order direction
	*
	* @return void
	*
	* @throws Exception
	*/
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "DESC");
		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);
			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}
	/**
	* Method to get a store id based on model configuration state.
	*
	* This is necessary because the model is used by the component and
	* different modules that might need different sets of data or different
	* ordering requirements.
	*
	* @param	string	$id	A prefix for the store id.
	*
	* @return	string A store id.
	*
	* @since	1.0.0
	*/
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}
	/**
	* Build an SQL query to load the list data.
	*
	* @return	DatabaseQuery
	*
	* @since	1.0.0
	*/
	protected function getListQuery()
	{
		// Create a new query object.
		$db	= $this->getDbo();
		$query = $db->getQuery(true);
		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__shopping_order` AS a');
		
		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}
		
		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.id LIKE ' . $search . '  OR	a.ordering LIKE ' . $search . ' OR	a.state LIKE ' . $search . ' OR	a.title LIKE ' . $search . ' OR	a.number LIKE ' . $search . ' OR	a.items LIKE ' . $search . ' OR	a.total LIKE ' . $search . ' OR	a.name LIKE ' . $search . ' OR	a.phone LIKE ' . $search . ' OR	a.email LIKE ' . $search . ' OR	a.mobile LIKE ' . $search . ' OR	a.privonce LIKE ' . $search . ' OR	a.city LIKE ' . $search . ' OR	a.postal_code LIKE ' . $search . ' OR	a.order_date LIKE ' . $search . ' OR	a.bank_rfcode LIKE ' . $search . ' OR	a.post_rfcode LIKE ' . $search . ' OR	a.payment LIKE ' . $search . ' OR	a.created_by LIKE ' . $search . ' OR	a.status LIKE ' . $search . ' OR	a.token LIKE ' . $search . ')');
			}
		}
		
		// Filtering ordering
		$filter_ordering = $this->state->get("filter.ordering");
		if ($filter_ordering !== null && (is_numeric($filter_ordering) || !empty($filter_ordering)))
		{
			$query->where("a.`ordering` = '".$db->escape($filter_ordering)."'");
		}
		
		// Filtering state
		$filter_state = $this->state->get("filter.state");
		if ($filter_state !== null && (is_numeric($filter_state) || !empty($filter_state)))
		{
			$query->where("a.`state` = '".$db->escape($filter_state)."'");
		}
		
		// Filtering title
		$filter_title = $this->state->get("filter.title");
		if ($filter_title !== null && (is_numeric($filter_title) || !empty($filter_title)))
		{
			$query->where("a.`title` = '".$db->escape($filter_title)."'");
		}
		
		// Filtering number
		$filter_number = $this->state->get("filter.number");
		if ($filter_number !== null && (is_numeric($filter_number) || !empty($filter_number)))
		{
			$query->where("a.`number` = '".$db->escape($filter_number)."'");
		}
		
		// Filtering items
		$filter_items = $this->state->get("filter.items");
		if ($filter_items !== null && (is_numeric($filter_items) || !empty($filter_items)))
		{
			$query->where("a.`items` = '".$db->escape($filter_items)."'");
		}
		
		// Filtering total
		$filter_total = $this->state->get("filter.total");
		if ($filter_total !== null && (is_numeric($filter_total) || !empty($filter_total)))
		{
			$query->where("a.`total` = '".$db->escape($filter_total)."'");
		}
		
		// Filtering name
		$filter_name = $this->state->get("filter.name");
		if ($filter_name !== null && (is_numeric($filter_name) || !empty($filter_name)))
		{
			$query->where("a.`name` = '".$db->escape($filter_name)."'");
		}
		
		// Filtering phone
		$filter_phone = $this->state->get("filter.phone");
		if ($filter_phone !== null && (is_numeric($filter_phone) || !empty($filter_phone)))
		{
			$query->where("a.`phone` = '".$db->escape($filter_phone)."'");
		}
		
		// Filtering email
		$filter_email = $this->state->get("filter.email");
		if ($filter_email !== null && (is_numeric($filter_email) || !empty($filter_email)))
		{
			$query->where("a.`email` = '".$db->escape($filter_email)."'");
		}
		
		// Filtering mobile
		$filter_mobile = $this->state->get("filter.mobile");
		if ($filter_mobile !== null && (is_numeric($filter_mobile) || !empty($filter_mobile)))
		{
			$query->where("a.`mobile` = '".$db->escape($filter_mobile)."'");
		}
		
		// Filtering privonce
		$filter_privonce = $this->state->get("filter.privonce");
		if ($filter_privonce !== null && (is_numeric($filter_privonce) || !empty($filter_privonce)))
		{
			$query->where("a.`privonce` = '".$db->escape($filter_privonce)."'");
		}
		
		// Filtering city
		$filter_city = $this->state->get("filter.city");
		if ($filter_city !== null && (is_numeric($filter_city) || !empty($filter_city)))
		{
			$query->where("a.`city` = '".$db->escape($filter_city)."'");
		}
		
		// Filtering postal_code
		$filter_postal_code = $this->state->get("filter.postal_code");
		if ($filter_postal_code !== null && (is_numeric($filter_postal_code) || !empty($filter_postal_code)))
		{
			$query->where("a.`postal_code` = '".$db->escape($filter_postal_code)."'");
		}
		
		// Filtering order_date
		$filter_order_date = $this->state->get("filter.order_date");
		if ($filter_order_date !== null && (is_numeric($filter_order_date) || !empty($filter_order_date)))
		{
			$query->where("a.`order_date` = '".$db->escape($filter_order_date)."'");
		}
		
		// Filtering bank_rfcode
		$filter_bank_rfcode = $this->state->get("filter.bank_rfcode");
		if ($filter_bank_rfcode !== null && (is_numeric($filter_bank_rfcode) || !empty($filter_bank_rfcode)))
		{
			$query->where("a.`bank_rfcode` = '".$db->escape($filter_bank_rfcode)."'");
		}
		
		// Filtering post_rfcode
		$filter_post_rfcode = $this->state->get("filter.post_rfcode");
		if ($filter_post_rfcode !== null && (is_numeric($filter_post_rfcode) || !empty($filter_post_rfcode)))
		{
			$query->where("a.`post_rfcode` = '".$db->escape($filter_post_rfcode)."'");
		}
		
		// Filtering payment
		$filter_payment = $this->state->get("filter.payment");
		if ($filter_payment !== null && (is_numeric($filter_payment) || !empty($filter_payment)))
		{
			$query->where("a.`payment` = '".$db->escape($filter_payment)."'");
		}
		
		// Filtering created_by
		$filter_created_by = $this->state->get("filter.created_by");
		if ($filter_created_by !== null && (is_numeric($filter_created_by) || !empty($filter_created_by)))
		{
			$query->where("a.`created_by` = '".$db->escape($filter_created_by)."'");
		}
		
		// Filtering status
		$filter_status = $this->state->get("filter.status");
		if ($filter_status !== null && (is_numeric($filter_status) || !empty($filter_status)))
		{
			$query->where("a.`status` = '".$db->escape($filter_status)."'");
		}
		
		// Filtering token
		$filter_token = $this->state->get("filter.token");
		if ($filter_token !== null && (is_numeric($filter_token) || !empty($filter_token)))
		{
			$query->where("a.`token` = '".$db->escape($filter_token)."'");
		}
		
		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "DESC");
		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		return $query;
	}
	/**
	* Get an array of data items
	*
	* @return mixed Array of data items on success, false on failure.
	*/
	public function getItems()
	{
		$items = parent::getItems();
		foreach ($items as $oneItem)
		{
		}
		return $items;
	}
}
	