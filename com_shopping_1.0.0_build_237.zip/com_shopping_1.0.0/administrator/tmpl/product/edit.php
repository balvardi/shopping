<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
// No direct access
defined('_JEXEC') or die;
use \Joomla\CMS\HTML\HTMLHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Uri\Uri;
use \Joomla\CMS\Router\Route;
use \Joomla\CMS\Language\Text;
$wa = $this->document->getWebAssetManager();
$wa->useScript('keepalive')
	->useScript('form.validate');
HTMLHelper::_('bootstrap.tooltip');
?>
<form action="<?php echo Route::_('index.php?option=com_shopping&layout=edit&id=' . (int) $this->item->id); ?>" method="post" enctype="multipart/form-data" name="adminForm" id="product-form" class="form-validate form-horizontal">
	<?php echo HTMLHelper::_('uitab.startTabSet', 'myTab', array('active' => 'product')); ?>
	<?php echo HTMLHelper::_('uitab.addTab', 'myTab', 'product', Text::_('COM_SHOPPING_TAB_PRODUCT', true)); ?>
	<div class="row-fluid">
		<div class="col-md-12 form-horizontal">
			<fieldset class="adminform">
				<?php echo $this->form->renderField('id'); ?>
				<?php echo $this->form->renderField('ordering'); ?>
				<?php echo $this->form->renderField('state'); ?>
				<?php echo $this->form->renderField('title'); ?>
				<?php echo $this->form->renderField('alias'); ?>
				<?php echo $this->form->renderField('photo'); ?>
				<?php if (!empty($this->item->photo)) : ?>
					<?php $photoFiles = array(); ?>
					<?php foreach ((array)$this->item->photo as $fileSingle) : ?>
						<?php if (!is_array($fileSingle)) : ?>
							<a href="<?php echo Route::_(Uri::root() . 'images/photo'. DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
							<?php $photoFiles[] = $fileSingle; ?>
						<?php endif; ?>
					<?php endforeach; ?>
					<input type="hidden" name="jform[photo_hidden]" id="jform_photo_hidden" value="<?php echo implode(',', $photoFiles); ?>" />
				<?php endif; ?>
				<?php echo $this->form->renderField('gallery'); ?>
				<?php if (!empty($this->item->gallery)) : ?>
					<?php $galleryFiles = array(); ?>
					<?php foreach ((array)$this->item->gallery as $fileSingle) : ?>
						<?php if (!is_array($fileSingle)) : ?>
							<a href="<?php echo Route::_(Uri::root() . 'images/gallery'. DIRECTORY_SEPARATOR . $fileSingle, false);?>"><?php echo $fileSingle; ?></a> | 
							<?php $galleryFiles[] = $fileSingle; ?>
						<?php endif; ?>
					<?php endforeach; ?>
					<input type="hidden" name="jform[gallery_hidden]" id="jform_gallery_hidden" value="<?php echo implode(',', $galleryFiles); ?>" />
				<?php endif; ?>
				<?php echo $this->form->renderField('category'); ?>
				<?php echo $this->form->renderField('description'); ?>
				<?php echo $this->form->renderField('price'); ?>
				<?php echo $this->form->renderField('label'); ?>
				<?php echo $this->form->renderField('weight'); ?>
				<?php echo $this->form->renderField('stock'); ?>
				<?php echo $this->form->renderField('discount'); ?>
				<?php echo $this->form->renderField('discount_date'); ?>
				<?php echo $this->form->renderField('hits'); ?>
				<?php echo $this->form->renderField('created_date'); ?>
				<?php echo $this->form->renderField('param'); ?>
			</fieldset>
		</div>
	</div>
	<?php echo HTMLHelper::_('uitab.endTab'); ?>
	<?php echo HTMLHelper::_('uitab.endTabSet'); ?>
	<input type="hidden" name="task" value=""/>
	<?php echo HTMLHelper::_('form.token'); ?>
</form>
		