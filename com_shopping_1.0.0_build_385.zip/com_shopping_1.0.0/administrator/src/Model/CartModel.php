<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Shopping\Component\Shopping\Administrator\Helper\ShoppingHelper;
/**
 * Methods supporting a list of Cart records.
 *
 * @since	1.0.0
 */
class CartModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param	array	$config	An optional associative array of configuration settings.
	*
	* @see		JController
	* @since		1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			
				'id', 'a.id',
				'created_by', 'a.created_by',
				'product', 'a.product',
				'order_id', 'a.order_id',
				'paymented', 'a.paymented',
			);
		}
		parent::__construct($config);
	}
	
	
	
	/**
	* Method to auto-populate the model state.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @param	string	$ordering	Elements order
	* @param	string	$direction	Order direction
	*
	* @return void
	*
	* @throws Exception
	*/
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "ASC");
		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);
			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}
	/**
	* Method to get a store id based on model configuration state.
	*
	* This is necessary because the model is used by the component and
	* different modules that might need different sets of data or different
	* ordering requirements.
	*
	* @param	string	$id	A prefix for the store id.
	*
	* @return	string A store id.
	*
	* @since	1.0.0
	*/
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}
	/**
	* Build an SQL query to load the list data.
	*
	* @return	DatabaseQuery
	*
	* @since	1.0.0
	*/
	protected function getListQuery()
	{
		// Create a new query object.
		$db	= $this->getDbo();
		$query = $db->getQuery(true);
		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__shopping_cart` AS a');
		
		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.id LIKE ' . $search . '  OR	a.created_by LIKE ' . $search . ' OR	a.product LIKE ' . $search . ' OR	a.order_id LIKE ' . $search . ' OR	a.paymented LIKE ' . $search . ')');
			}
		}
		
		// Filtering created_by
		$filter_created_by = $this->state->get("filter.created_by");
		if ($filter_created_by !== null && (is_numeric($filter_created_by) || !empty($filter_created_by)))
		{
			$query->where("a.`created_by` = '".$db->escape($filter_created_by)."'");
		}
		
		// Filtering product
		$filter_product = $this->state->get("filter.product");
		if ($filter_product !== null && (is_numeric($filter_product) || !empty($filter_product)))
		{
			$query->where("a.`product` = '".$db->escape($filter_product)."'");
		}
		
		// Filtering order_id
		$filter_order_id = $this->state->get("filter.order_id");
		if ($filter_order_id !== null && (is_numeric($filter_order_id) || !empty($filter_order_id)))
		{
			$query->where("a.`order_id` = '".$db->escape($filter_order_id)."'");
		}
		
		// Filtering paymented
		$filter_paymented = $this->state->get("filter.paymented");
		if ($filter_paymented !== null && (is_numeric($filter_paymented) || !empty($filter_paymented)))
		{
			$query->where("a.`paymented` = '".$db->escape($filter_paymented)."'");
		}
		
		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "ASC");
		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		return $query;
	}
	/**
	* Get an array of data items
	*
	* @return mixed Array of data items on success, false on failure.
	*/
	public function getItems()
	{
		$items = parent::getItems();
		foreach ($items as $oneItem)
		{
		}
		return $items;
	}
}
	