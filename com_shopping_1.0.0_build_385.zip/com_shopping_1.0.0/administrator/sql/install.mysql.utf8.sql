
CREATE TABLE IF NOT EXISTS `#__shopping_vendor` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`phone` VARCHAR(255)	NULL	DEFAULT "",
	`email` VARCHAR(255)	NULL	DEFAULT "",
	`privonce` VARCHAR(255)	NULL	DEFAULT "",
	`city` VARCHAR(255)	NULL	DEFAULT "",
	`address` TEXT NULL,
	`postal_code` VARCHAR(255)	NULL	DEFAULT "",
	`user` INT(11)	NULL	DEFAULT 0,
	`location` TEXT NULL,
	`logo` TEXT NULL,
	`gallery` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_category` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`photo` TEXT NULL,
	`parent` VARCHAR(255)	NULL	DEFAULT "",
	`description` TEXT NULL,
	`hits` INT(11)	NULL	DEFAULT 0,
	`fields` VARCHAR(255)	NULL	DEFAULT "",
	`created_date` DATETIME NULL	DEFAULT NULL ,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_product` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`photo` TEXT NULL,
	`gallery` TEXT NULL,
	`category` VARCHAR(255)	NULL	DEFAULT "",
	`vendor` VARCHAR(255)	NULL	DEFAULT "",
	`company` VARCHAR(255)	NULL	DEFAULT "",
	`description` TEXT NULL,
	`price` INT(11)	NULL	DEFAULT 0,
	`label` TEXT NULL,
	`weight` INT(11)	NULL	DEFAULT 0,
	`stock` INT(11)	NULL	DEFAULT 0,
	`discount` INT(11)	NULL	DEFAULT 0,
	`discount_date` DATETIME NULL	DEFAULT NULL ,
	`video` VARCHAR(255)	NULL	DEFAULT "",
	`download_link` VARCHAR(255)	NULL	DEFAULT "",
	`aparat` VARCHAR(255)	NULL	DEFAULT "",
	`param` TEXT NULL,
	`sale` INT(11)	NULL	DEFAULT 0,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_field` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`type` TEXT NULL,
	`options` TEXT NULL,
	`category` VARCHAR(255)	NULL	DEFAULT "",
	`section` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_campaign` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`description` TEXT NULL,
	`photo` TEXT NULL,
	`banner` TEXT NULL,
	`start_date` DATETIME NULL	DEFAULT NULL ,
	`end_date` DATETIME NULL	DEFAULT NULL ,
	`discount` INT(11)	NULL	DEFAULT 0,
	`hits` INT(11)	NULL	DEFAULT 0,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	`products` VARCHAR(255)	NULL	DEFAULT "",
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_discount` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`code` VARCHAR(255)	NULL	DEFAULT "",
	`start_date` DATETIME NULL	DEFAULT NULL ,
	`end_date` DATETIME NULL	DEFAULT NULL ,
	`discount` INT(11)	NULL	DEFAULT 0,
	`number` INT(11)	NULL	DEFAULT 0,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	`products` VARCHAR(255)	NULL	DEFAULT "",
	`categories` VARCHAR(255)	NULL	DEFAULT "",
	`member` VARCHAR(255)	NULL	DEFAULT "",
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_order` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`number` INT(11)	NULL	DEFAULT 0,
	`items` TEXT NULL,
	`total` INT(11)	NULL	DEFAULT 0,
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`phone` VARCHAR(255)	NULL	DEFAULT "",
	`email` VARCHAR(255)	NULL	DEFAULT "",
	`mobile` VARCHAR(255)	NULL	DEFAULT "",
	`privonce` VARCHAR(255)	NULL	DEFAULT "",
	`city` VARCHAR(255)	NULL	DEFAULT "",
	`postal_code` VARCHAR(255)	NULL	DEFAULT "",
	`order_date` DATETIME NULL	DEFAULT NULL ,
	`bank_rfcode` VARCHAR(255)	NULL	DEFAULT "",
	`post_rfcode` VARCHAR(255)	NULL	DEFAULT "",
	`payment` TEXT NULL,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`status` TEXT NULL,
	`token` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_address` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`phone` VARCHAR(255)	NULL	DEFAULT "",
	`email` VARCHAR(255)	NULL	DEFAULT "",
	`privonce` VARCHAR(255)	NULL	DEFAULT "",
	`city` VARCHAR(255)	NULL	DEFAULT "",
	`address` TEXT NULL,
	`postal_code` VARCHAR(255)	NULL	DEFAULT "",
	`user` INT(11)	NULL	DEFAULT 0,
	`location` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_user` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`phone` VARCHAR(255)	NULL	DEFAULT "",
	`email` VARCHAR(255)	NULL	DEFAULT "",
	`privonce` VARCHAR(255)	NULL	DEFAULT "",
	`city` VARCHAR(255)	NULL	DEFAULT "",
	`address` TEXT NULL,
	`postal_code` VARCHAR(255)	NULL	DEFAULT "",
	`created_by` INT(11)	NULL	DEFAULT 0,
	`location` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_province` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255)	NULL	DEFAULT "",
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_city` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`privonce` VARCHAR(255)	NULL	DEFAULT "",
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_gateway` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`script` VARCHAR(255)	NULL	DEFAULT "",
	`type` TEXT NULL,
	`params` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_shipping` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`script` VARCHAR(255)	NULL	DEFAULT "",
	`type` TEXT NULL,
	`params` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_behavior` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`page_url` VARCHAR(255)	NULL	DEFAULT "",
	`visit_time` VARCHAR(255)	NULL	DEFAULT "",
	`action_type` VARCHAR(255)	NULL	DEFAULT "",
	`device_info` VARCHAR(255)	NULL	DEFAULT "",
	`time_on_page` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_analysis` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`total_visits` INT(11)	NULL	DEFAULT 0,
	`most_visited_page` VARCHAR(255)	NULL	DEFAULT "",
	`last_visit` DATETIME NULL	DEFAULT NULL ,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_recommender_visits` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`page_url` VARCHAR(255)	NULL	DEFAULT "",
	`visit_time` DATETIME NULL	DEFAULT NULL ,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_favorites` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`product` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_search` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`product` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_compare` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`product` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_cart` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`product` INT(11)	NULL	DEFAULT 0,
	`order_id` INT(11)	NULL	DEFAULT 0,
	`paymented` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_comment` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`created_by` INT(11)	NULL	DEFAULT 0,
	`item` INT(11)	NULL	DEFAULT 0,
	`type` TEXT NULL,
	`comment` TEXT NULL,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_api_keys` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`key` VARCHAR(255)	NULL	DEFAULT "",
	`created_by` INT(11)	NULL	DEFAULT 0,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	`state` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_notification` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`message` TEXT NULL,
	`send_to` INT(11)	NULL	DEFAULT 0,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	`status` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_company` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`phone` VARCHAR(255)	NULL	DEFAULT "",
	`email` VARCHAR(255)	NULL	DEFAULT "",
	`privonce` VARCHAR(255)	NULL	DEFAULT "",
	`city` VARCHAR(255)	NULL	DEFAULT "",
	`address` TEXT NULL,
	`postal_code` VARCHAR(255)	NULL	DEFAULT "",
	`user` INT(11)	NULL	DEFAULT 0,
	`location` TEXT NULL,
	`logo` TEXT NULL,
	`gallery` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;
