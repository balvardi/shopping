<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\View\Dashboard;
// No direct access
defined('_JEXEC') or die;
use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
/**
 * View class for a list of Shopping.
 *
 * @since	1.0.0
 */
class HtmlView extends BaseHtmlView{
}