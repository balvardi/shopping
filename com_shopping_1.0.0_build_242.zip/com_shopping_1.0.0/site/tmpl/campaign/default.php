<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	// No direct access
	defined('_JEXEC') or die;
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Joomla\CMS\Session\Session;
	use Joomla\Utilities\ArrayHelper;
?>
<div class="container campaign-content">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
	<?php endif;?>
	<div class="text-data">
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_ID'); ?></div>
			<div class="col-md-9"><?php echo $this->item->id; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_ORDERING'); ?></div>
			<div class="col-md-9"><?php echo $this->item->ordering; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_STATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->state; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_TITLE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->title; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_ALIAS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->alias; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_DESCRIPTION'); ?></div>
			<div class="col-md-9"><?php echo $this->item->description; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_PHOTO'); ?></div>
			<div class="col-md-9">
				<?php
					foreach ((array) $this->item->photo as $singleFile) : 
						if (!is_array($singleFile)) : 
							$uploadPath = 'images/photo' . DIRECTORY_SEPARATOR . $singleFile;
							echo '<a href="' . Route::_(Uri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
						endif;
					endforeach;
					?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_BANNER'); ?></div>
			<div class="col-md-9">
				<?php
					foreach ((array) $this->item->banner as $singleFile) : 
						if (!is_array($singleFile)) : 
							$uploadPath = 'images/banner' . DIRECTORY_SEPARATOR . $singleFile;
							echo '<a href="' . Route::_(Uri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
						endif;
					endforeach;
					?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_START_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->start_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_END_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->end_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_DISCOUNT'); ?></div>
			<div class="col-md-9"><?php echo $this->item->discount; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_HITS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->hits; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_CREATED_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->created_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_CAMPAIGN_PRODUCTS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->products; ?></div>
		</div>
	</div>
</div>