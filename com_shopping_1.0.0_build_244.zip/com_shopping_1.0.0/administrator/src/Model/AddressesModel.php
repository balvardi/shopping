<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Shopping\Component\Shopping\Administrator\Helper\ShoppingHelper;
/**
 * Methods supporting a list of Addresses records.
 *
 * @since	1.0.0
 */
class AddressesModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param	array	$config	An optional associative array of configuration settings.
	*
	* @see		JController
	* @since		1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			
				'id', 'a.id',
				'ordering', 'a.ordering',
				'state', 'a.state',
				'title', 'a.title',
				'name', 'a.name',
				'phone', 'a.phone',
				'email', 'a.email',
				'province', 'a.province',
				'city', 'a.city',
				'address', 'a.address',
				'postal_code', 'a.postal_code',
				'user', 'a.user',
				'location', 'a.location',
			);
		}
		parent::__construct($config);
	}
	
	
	
	/**
	* Method to auto-populate the model state.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @param	string	$ordering	Elements order
	* @param	string	$direction	Order direction
	*
	* @return void
	*
	* @throws Exception
	*/
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "DESC");
		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);
			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}
	/**
	* Method to get a store id based on model configuration state.
	*
	* This is necessary because the model is used by the component and
	* different modules that might need different sets of data or different
	* ordering requirements.
	*
	* @param	string	$id	A prefix for the store id.
	*
	* @return	string A store id.
	*
	* @since	1.0.0
	*/
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}
	/**
	* Build an SQL query to load the list data.
	*
	* @return	DatabaseQuery
	*
	* @since	1.0.0
	*/
	protected function getListQuery()
	{
		// Create a new query object.
		$db	= $this->getDbo();
		$query = $db->getQuery(true);
		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__shopping_address` AS a');
		
		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}
		
		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.id LIKE ' . $search . '  OR	a.ordering LIKE ' . $search . ' OR	a.state LIKE ' . $search . ' OR	a.title LIKE ' . $search . ' OR	a.name LIKE ' . $search . ' OR	a.phone LIKE ' . $search . ' OR	a.email LIKE ' . $search . ' OR	a.province LIKE ' . $search . ' OR	a.city LIKE ' . $search . ' OR	a.address LIKE ' . $search . ' OR	a.postal_code LIKE ' . $search . ' OR	a.user LIKE ' . $search . ' OR	a.location LIKE ' . $search . ')');
			}
		}
		
		// Filtering ordering
		$filter_ordering = $this->state->get("filter.ordering");
		if ($filter_ordering !== null && (is_numeric($filter_ordering) || !empty($filter_ordering)))
		{
			$query->where("a.`ordering` = '".$db->escape($filter_ordering)."'");
		}
		
		// Filtering state
		$filter_state = $this->state->get("filter.state");
		if ($filter_state !== null && (is_numeric($filter_state) || !empty($filter_state)))
		{
			$query->where("a.`state` = '".$db->escape($filter_state)."'");
		}
		
		// Filtering title
		$filter_title = $this->state->get("filter.title");
		if ($filter_title !== null && (is_numeric($filter_title) || !empty($filter_title)))
		{
			$query->where("a.`title` = '".$db->escape($filter_title)."'");
		}
		
		// Filtering name
		$filter_name = $this->state->get("filter.name");
		if ($filter_name !== null && (is_numeric($filter_name) || !empty($filter_name)))
		{
			$query->where("a.`name` = '".$db->escape($filter_name)."'");
		}
		
		// Filtering phone
		$filter_phone = $this->state->get("filter.phone");
		if ($filter_phone !== null && (is_numeric($filter_phone) || !empty($filter_phone)))
		{
			$query->where("a.`phone` = '".$db->escape($filter_phone)."'");
		}
		
		// Filtering email
		$filter_email = $this->state->get("filter.email");
		if ($filter_email !== null && (is_numeric($filter_email) || !empty($filter_email)))
		{
			$query->where("a.`email` = '".$db->escape($filter_email)."'");
		}
		
		// Filtering province
		$filter_province = $this->state->get("filter.province");
		if ($filter_province !== null && (is_numeric($filter_province) || !empty($filter_province)))
		{
			$query->where("a.`province` = '".$db->escape($filter_province)."'");
		}
		
		// Filtering city
		$filter_city = $this->state->get("filter.city");
		if ($filter_city !== null && (is_numeric($filter_city) || !empty($filter_city)))
		{
			$query->where("a.`city` = '".$db->escape($filter_city)."'");
		}
		
		// Filtering address
		$filter_address = $this->state->get("filter.address");
		if ($filter_address !== null && (is_numeric($filter_address) || !empty($filter_address)))
		{
			$query->where("a.`address` = '".$db->escape($filter_address)."'");
		}
		
		// Filtering postal_code
		$filter_postal_code = $this->state->get("filter.postal_code");
		if ($filter_postal_code !== null && (is_numeric($filter_postal_code) || !empty($filter_postal_code)))
		{
			$query->where("a.`postal_code` = '".$db->escape($filter_postal_code)."'");
		}
		
		// Filtering user
		$filter_user = $this->state->get("filter.user");
		if ($filter_user !== null && (is_numeric($filter_user) || !empty($filter_user)))
		{
			$query->where("a.`user` = '".$db->escape($filter_user)."'");
		}
		
		// Filtering location
		$filter_location = $this->state->get("filter.location");
		if ($filter_location !== null && (is_numeric($filter_location) || !empty($filter_location)))
		{
			$query->where("a.`location` = '".$db->escape($filter_location)."'");
		}
		
		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "DESC");
		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		return $query;
	}
	/**
	* Get an array of data items
	*
	* @return mixed Array of data items on success, false on failure.
	*/
	public function getItems()
	{
		$items = parent::getItems();
		foreach ($items as $oneItem)
		{
		}
		return $items;
	}
}
	