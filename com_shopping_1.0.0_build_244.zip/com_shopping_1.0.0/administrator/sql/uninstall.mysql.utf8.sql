
DROP TABLE IF EXISTS `#__shopping_category`;

DROP TABLE IF EXISTS `#__shopping_product`;

DROP TABLE IF EXISTS `#__shopping_field`;

DROP TABLE IF EXISTS `#__shopping_campaign`;

DROP TABLE IF EXISTS `#__shopping_order`;

DROP TABLE IF EXISTS `#__shopping_address`;
