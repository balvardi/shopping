
CREATE TABLE IF NOT EXISTS `#__shopping_category` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`photo` TEXT NULL,
	`parent` VARCHAR(255)	NULL	DEFAULT "",
	`description` TEXT NULL,
	`hits` INT(11)	NULL	DEFAULT 0,
	`fields` VARCHAR(255)	NULL	DEFAULT "",
	`created_date` DATETIME NULL	DEFAULT NULL ,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_product` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`photo` TEXT NULL,
	`gallery` TEXT NULL,
	`category` VARCHAR(255)	NULL	DEFAULT "",
	`description` TEXT NULL,
	`price` INT(11)	NULL	DEFAULT 0,
	`label` TEXT NULL,
	`weight` INT(11)	NULL	DEFAULT 0,
	`stock` INT(11)	NULL	DEFAULT 0,
	`discount` INT(11)	NULL	DEFAULT 0,
	`discount_date` DATETIME NULL	DEFAULT NULL ,
	`video` VARCHAR(255)	NULL	DEFAULT "",
	`download_link` VARCHAR(255)	NULL	DEFAULT "",
	`aparat` VARCHAR(255)	NULL	DEFAULT "",
	`param` TEXT NULL,
	`hits` INT(11)	NULL	DEFAULT 0,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_field` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`type` TEXT NULL,
	`options` TEXT NULL,
	`category` VARCHAR(255)	NULL	DEFAULT "",
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_campaign` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`alias` VARCHAR(255)	NULL	DEFAULT "",
	`description` TEXT NULL,
	`photo` TEXT NULL,
	`banner` TEXT NULL,
	`start_date` DATETIME NULL	DEFAULT NULL ,
	`end_date` DATETIME NULL	DEFAULT NULL ,
	`discount` INT(11)	NULL	DEFAULT 0,
	`hits` INT(11)	NULL	DEFAULT 0,
	`created_date` DATETIME NULL	DEFAULT NULL ,
	`products` VARCHAR(255)	NULL	DEFAULT "",
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_order` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`number` INT(11)	NULL	DEFAULT 0,
	`items` TEXT NULL,
	`total` INT(11)	NULL	DEFAULT 0,
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`phone` VARCHAR(255)	NULL	DEFAULT "",
	`email` VARCHAR(255)	NULL	DEFAULT "",
	`province` VARCHAR(255)	NULL	DEFAULT "",
	`city` VARCHAR(255)	NULL	DEFAULT "",
	`address` TEXT NULL,
	`postal_code` VARCHAR(255)	NULL	DEFAULT "",
	`order_date` DATETIME NULL	DEFAULT NULL ,
	`bank_rfcode` VARCHAR(255)	NULL	DEFAULT "",
	`post_rfcode` VARCHAR(255)	NULL	DEFAULT "",
	`payment` TEXT NULL,
	`user` INT(11)	NULL	DEFAULT 0,
	`status` TEXT NULL,
	`token` INT(11)	NULL	DEFAULT 0,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `#__shopping_address` (
	`id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
	`ordering` INT(11)	NULL	DEFAULT 0,
	`state` INT(11)	NULL	DEFAULT 0,
	`title` VARCHAR(255)	NULL	DEFAULT "",
	`name` VARCHAR(255)	NULL	DEFAULT "",
	`phone` VARCHAR(255)	NULL	DEFAULT "",
	`email` VARCHAR(255)	NULL	DEFAULT "",
	`province` VARCHAR(255)	NULL	DEFAULT "",
	`city` VARCHAR(255)	NULL	DEFAULT "",
	`address` TEXT NULL,
	`postal_code` VARCHAR(255)	NULL	DEFAULT "",
	`user` INT(11)	NULL	DEFAULT 0,
	`location` TEXT NULL,
	PRIMARY KEY (`id`)
	) DEFAULT COLLATE=utf8mb4_unicode_ci;
