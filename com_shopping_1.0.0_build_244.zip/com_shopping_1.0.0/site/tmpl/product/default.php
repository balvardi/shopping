<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	// No direct access
	defined('_JEXEC') or die;
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Joomla\CMS\Session\Session;
	use Joomla\Utilities\ArrayHelper;
?>
<div class="container product-content">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
	<?php endif;?>
	<div class="text-data">
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_ID'); ?></div>
			<div class="col-md-9"><?php echo $this->item->id; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_ORDERING'); ?></div>
			<div class="col-md-9"><?php echo $this->item->ordering; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_STATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->state; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_TITLE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->title; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_ALIAS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->alias; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_PHOTO'); ?></div>
			<div class="col-md-9">
				<?php
					foreach ((array) $this->item->photo as $singleFile) : 
						if (!is_array($singleFile)) : 
							$uploadPath = 'images/photo' . DIRECTORY_SEPARATOR . $singleFile;
							echo '<a href="' . Route::_(Uri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
						endif;
					endforeach;
					?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_GALLERY'); ?></div>
			<div class="col-md-9">
				<?php
					foreach ((array) $this->item->gallery as $singleFile) : 
						if (!is_array($singleFile)) : 
							$uploadPath = 'images/gallery' . DIRECTORY_SEPARATOR . $singleFile;
							echo '<a href="' . Route::_(Uri::root() . $uploadPath, false) . '" target="_blank">' . $singleFile . '</a> ';
						endif;
					endforeach;
					?>
			</div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_CATEGORY'); ?></div>
			<div class="col-md-9"><?php echo $this->item->category; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_DESCRIPTION'); ?></div>
			<div class="col-md-9"><?php echo $this->item->description; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_PRICE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->price; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_LABEL'); ?></div>
			<div class="col-md-9"><?php echo $this->item->label; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_WEIGHT'); ?></div>
			<div class="col-md-9"><?php echo $this->item->weight; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_STOCK'); ?></div>
			<div class="col-md-9"><?php echo $this->item->stock; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_DISCOUNT'); ?></div>
			<div class="col-md-9"><?php echo $this->item->discount; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_DISCOUNT_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->discount_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_VIDEO'); ?></div>
			<div class="col-md-9"><?php echo $this->item->video; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_DOWNLOAD'); ?></div>
			<div class="col-md-9"><?php echo $this->item->download; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_DOWNLOAD_LINK'); ?></div>
			<div class="col-md-9"><?php echo $this->item->download_link; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_APARAT'); ?></div>
			<div class="col-md-9"><?php echo $this->item->aparat; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_PARAM'); ?></div>
			<div class="col-md-9"><?php echo $this->item->param; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_HITS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->hits; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_PRODUCT_CREATED_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->created_date; ?></div>
		</div>
	</div>
</div>