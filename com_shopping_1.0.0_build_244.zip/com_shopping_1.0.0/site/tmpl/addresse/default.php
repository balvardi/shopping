<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	// No direct access
	defined('_JEXEC') or die;
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Joomla\CMS\Session\Session;
	use Joomla\Utilities\ArrayHelper;
?>
<div class="container addresse-content">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
	<?php endif;?>
	<div class="text-data">
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_ID'); ?></div>
			<div class="col-md-9"><?php echo $this->item->id; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_ORDERING'); ?></div>
			<div class="col-md-9"><?php echo $this->item->ordering; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_STATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->state; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_TITLE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->title; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_NAME'); ?></div>
			<div class="col-md-9"><?php echo $this->item->name; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_PHONE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->phone; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_EMAIL'); ?></div>
			<div class="col-md-9"><?php echo $this->item->email; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_PROVINCE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->province; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_CITY'); ?></div>
			<div class="col-md-9"><?php echo $this->item->city; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_ADDRESS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->address; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_POSTAL_CODE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->postal_code; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_USER'); ?></div>
			<div class="col-md-9"><?php echo $this->item->user; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ADDRESSE_LOCATION'); ?></div>
			<div class="col-md-9"><?php echo $this->item->location; ?></div>
		</div>
	</div>
</div>