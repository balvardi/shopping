<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Site\Dispatcher;
defined('JPATH_PLATFORM') or die;
use Joomla\CMS\Dispatcher\ComponentDispatcher;
use Joomla\CMS\Language\Text;
/**
 * ComponentDispatcher class for Com_shopping
 *
 * @since	1.0.0
 */
class Dispatcher extends ComponentDispatcher
{
	/**
	* Dispatch a controller task. Redirecting the user if appropriate.
	*
	* @return	void
	*
	* @since	1.0.0
	*/
	public function dispatch()
	{
		parent::dispatch();
	}
}
		