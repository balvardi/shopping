<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Controller;
\defined('_JEXEC') or die;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Factory;
use Joomla\CMS\Language\Multilanguage;
use Joomla\CMS\Language\Text;
use Joomla\CMS\MVC\Controller\AdminController;
use Joomla\CMS\Router\Route;
use Joomla\CMS\Uri\Uri;
use Joomla\Utilities\ArrayHelper;
/**
 * Notifications list controller class.
 *
 * @since	1.0.0
 */
class NotificationsController extends AdminController
{
	/**
	* Method to clone existing Notifications
	*
	* @return	void
	*
	* @throws	Exception
	*/
	public function duplicate()
	{
		// Check for notification forgeries
		$this->checkToken();
		// Get id(s)
		$pks = $this->input->post->get('cid', array(), 'array');
		try
		{
			if (empty($pks))
			{
				throw new \Exception(Text::_('COM_COM_SHOPPING_NO_ELEMENT_SELECTED'));
			}
			ArrayHelper::toInteger($pks);
			$model = $this->getModel();
			$model->duplicate($pks);
			$this->setMessage(Text::_('COM_COM_SHOPPING_ITEMS_SUCCESS_DUPLICATED'));
		}
		catch (\Exception $e)
		{
			Factory::getApplication()->enqueueMessage($e->getMessage(), 'warning');
		}
		$this->setRedirect('index.php?option=com_COM_SHOPPING&view=Notifications');
	}
	/**
	* Proxy for getModel.
	*
	* @param	string	$name	Optional. Model name
	* @param	string	$prefix	Optional. Class prefix
	* @param	array	$config	Optional. Configuration array for model
	*
	* @return	object	The Model
	*
	* @since	1.0.0
	*/
	public function getModel($name = 'notification', $prefix = 'Administrator', $config = array())
	{
		return parent::getModel($name, $prefix, array('ignore_request' => true));
	}
	
	/**
	* Method to save the submitted ordering values for records via AJAX.
	*
	* @return	void
	*
	* @since	1.0.0
	*
	* @throws	Exception
	*/
	public function saveOrderAjax()
	{
		// Get the input
		$pks	= $this->input->post->get('cid', array(), 'array');
		$order = $this->input->post->get('order', array(), 'array');
		// Sanitize the input
		ArrayHelper::toInteger($pks);
		ArrayHelper::toInteger($order);
		// Get the model
		$model = $this->getModel();
		// Save the ordering
		$return = $model->saveorder($pks, $order);
		if ($return)
		{
			echo "1";
		}
		// Close the application
		Factory::getApplication()->close();
	}
	/**
	* Method to toggle fields on a list
	*
	* @throws Exception
	*/
	public function toggle()
	{
		// Initialise variables
		$app	= Factory::getApplication();
		$ids	= $this->input->get('cid', array(), '', 'array');
		$field	= $this->input->get('field');
		if (empty($ids))
		{
			$app->enqueueMessage('warning', Text::_('JERROR_NO_ITEMS_SELECTED'));
		}
		else
		{
			// Get the model
			$model = $this->getModel('notification');
			foreach ($ids as $pk)
			{
				// Toggle the items
				if (!$model->toggle($pk, $field))
				{
					throw new \Exception($model->getError(), 500);
				}
			}
		}
	$this->setRedirect(Route::_('index.php?option=' . $this->input->get('option') . '&view=' . $this->input->get('view'), false));
	}
}
		