<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Site\Service;
// No direct access
defined('_JEXEC') or die;
use \Joomla\CMS\Categories\Categories;
/**
 * Content Component Category Tree
 *
 * @since	1.0.0
 */
class Category extends Categories
{
	/**
	* Class constructor
	*
	* @param	array	$options	Array of options
	*
	* @since	11.1
	*/
	public function __construct($options = array())
	{
		$options['table'] = '#__shopping_category';
		$options['state'] = '1';
		parent::__construct($options);
	}
}
		