<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Site\Service;
// No direct access
defined('_JEXEC') or die;
use Joomla\CMS\Component\Router\RouterViewConfiguration;
use Joomla\CMS\Component\Router\RouterView;
use Joomla\CMS\Component\Router\Rules\StandardRules;
use Joomla\CMS\Component\Router\Rules\NomenuRules;
use Joomla\CMS\Component\Router\Rules\MenuRules;
use Joomla\CMS\Factory;
use Joomla\CMS\Categories\Categories;
use Joomla\CMS\Application\SiteApplication;
use Joomla\CMS\Categories\CategoryFactoryInterface;
use Joomla\CMS\Categories\CategoryInterface;
use Joomla\Database\DatabaseInterface;
use Joomla\CMS\Menu\AbstractMenu;
use Joomla\CMS\Component\ComponentHelper;
/**
 * Class ShoppingRouter
 *
 */
class Router extends RouterView
{
	private $noIDs;
	/**
	* The category factory
	*
	* @var	CategoryFactoryInterface
	*
	* @since	1.0.0
	*/
	private $categoryFactory;
	/**
	* The category cache
	*
	* @var	array
	*
	* @since	1.0.0
	*/
	private $categoryCache = [];
	public function __construct(SiteApplication $app, AbstractMenu $menu, CategoryFactoryInterface $categoryFactory, DatabaseInterface $db)
	{
		$params = ComponentHelper::getParams('com_shopping');
		$this->noIDs = (bool) $params->get('sef_ids');
		$this->categoryFactory = $categoryFactory;
		
      $vendors = new RouterViewConfiguration('vendors');
      $vendors->setKey('catid')->setNestable();
      $this->registerView($vendors);
      $ccVendor = new RouterViewConfiguration('vendor');
      $ccVendor->setKey('id')->setParent($vendors, 'catid');
      $this->registerView($ccVendor);
      $vendorform = new RouterViewConfiguration('vendorform');
      $vendorform->setKey('id');
      $this->registerView($vendorform);
      $categories = new RouterViewConfiguration('categories');
      $categories->setKey('catid')->setNestable();
      $this->registerView($categories);
      $ccCategory = new RouterViewConfiguration('category');
      $ccCategory->setKey('id')->setParent($categories, 'catid');
      $this->registerView($ccCategory);
      $categoryform = new RouterViewConfiguration('categoryform');
      $categoryform->setKey('id');
      $this->registerView($categoryform);
      $products = new RouterViewConfiguration('products');
      $products->setKey('catid')->setNestable();
      $this->registerView($products);
      $ccProduct = new RouterViewConfiguration('product');
      $ccProduct->setKey('id')->setParent($products, 'catid');
      $this->registerView($ccProduct);
      $productform = new RouterViewConfiguration('productform');
      $productform->setKey('id');
      $this->registerView($productform);
      $campaigns = new RouterViewConfiguration('campaigns');
      $campaigns->setKey('catid')->setNestable();
      $this->registerView($campaigns);
      $ccCampaign = new RouterViewConfiguration('campaign');
      $ccCampaign->setKey('id')->setParent($campaigns, 'catid');
      $this->registerView($ccCampaign);
      $campaignform = new RouterViewConfiguration('campaignform');
      $campaignform->setKey('id');
      $this->registerView($campaignform);
      $discounts = new RouterViewConfiguration('discounts');
      $discounts->setKey('catid')->setNestable();
      $this->registerView($discounts);
      $ccDiscount = new RouterViewConfiguration('discount');
      $ccDiscount->setKey('id')->setParent($discounts, 'catid');
      $this->registerView($ccDiscount);
      $discountform = new RouterViewConfiguration('discountform');
      $discountform->setKey('id');
      $this->registerView($discountform);
      $orders = new RouterViewConfiguration('orders');
      $orders->setKey('catid')->setNestable();
      $this->registerView($orders);
      $ccOrder = new RouterViewConfiguration('order');
      $ccOrder->setKey('id')->setParent($orders, 'catid');
      $this->registerView($ccOrder);
      $orderform = new RouterViewConfiguration('orderform');
      $orderform->setKey('id');
      $this->registerView($orderform);
      $addresses = new RouterViewConfiguration('addresses');
      $addresses->setKey('catid')->setNestable();
      $this->registerView($addresses);
      $ccAddresse = new RouterViewConfiguration('addresse');
      $ccAddresse->setKey('id')->setParent($addresses, 'catid');
      $this->registerView($ccAddresse);
      $addresseform = new RouterViewConfiguration('addresseform');
      $addresseform->setKey('id');
      $this->registerView($addresseform);
      $favorites = new RouterViewConfiguration('favorites');
      $favorites->setKey('catid')->setNestable();
      $this->registerView($favorites);
      $notifications = new RouterViewConfiguration('notifications');
      $notifications->setKey('catid')->setNestable();
      $this->registerView($notifications);
      $ccNotification = new RouterViewConfiguration('notification');
      $ccNotification->setKey('id')->setParent($notifications, 'catid');
      $this->registerView($ccNotification);
      $notificationform = new RouterViewConfiguration('notificationform');
      $notificationform->setKey('id');
      $this->registerView($notificationform);
      $companies = new RouterViewConfiguration('companies');
      $companies->setKey('catid')->setNestable();
      $this->registerView($companies);
      $ccCompany = new RouterViewConfiguration('company');
      $ccCompany->setKey('id')->setParent($companies, 'catid');
      $this->registerView($ccCompany);
      $companyform = new RouterViewConfiguration('companyform');
      $companyform->setKey('id');
      $this->registerView($companyform);
		$cart = new RouterViewConfiguration('cart');
		$this->registerView($cart);
		
		$dashboard = new RouterViewConfiguration('dashboard');
		$this->registerView($dashboard);
		
		$login = new RouterViewConfiguration('login');
		$this->registerView($login);
		
		$update = new RouterViewConfiguration('update');
		$this->registerView($update);
		
		$featuread = new RouterViewConfiguration('featuread');
		$this->registerView($featuread);
		
		$setting = new RouterViewConfiguration('setting');
		$this->registerView($setting);
		
		$profile = new RouterViewConfiguration('profile');
		$this->registerView($profile);
		
		$search = new RouterViewConfiguration('search');
		$this->registerView($search);
		
		$import = new RouterViewConfiguration('import');
		$this->registerView($import);
		
		$export = new RouterViewConfiguration('export');
		$this->registerView($export);
		
		$download = new RouterViewConfiguration('download');
		$this->registerView($download);
		
		$checkout = new RouterViewConfiguration('checkout');
		$this->registerView($checkout);
		
		$json = new RouterViewConfiguration('json');
		$this->registerView($json);
		
		$manager = new RouterViewConfiguration('manager');
		$this->registerView($manager);
		
		$compare = new RouterViewConfiguration('compare');
		$this->registerView($compare);
		
		parent::__construct($app, $menu);
		$this->attachRule(new MenuRules($this));
		$this->attachRule(new StandardRules($this));
		$this->attachRule(new NomenuRules($this));
	}
	
	/**
		* Method to get the segment(s) for a category
		*
		* @param	string	$id	ID of the category to retrieve the segments for
		* @param	array	$query	The request that is built right now
		*
		* @return	array|string	The segments of this item
	*/
		
		public function getVendorsSegment($id, $query){
         return $this->getVendorsSegment($id, $query);
		}
		public function getVendorsId($segment, $query){
         return $this->getVendorsId($segment, $query);
		}
		public function getVendorSegment($id, $query){
			if (!strpos($id, ':')){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('alias'))
					->from($dbquery->qn('#__shopping_vendor'))
					->where('id = ' . $dbquery->q($id));
				$db->setQuery($dbquery);
				$id .= ':' . $db->loadResult();
			}
			if ($this->noIDs){
				list($void, $segment) = explode(':', $id, 2);
				return array($void => $segment);
			}
			return array((int) $id => $id);
                  
		}
		public function getVendorId($segment, $query){
		
			if ($this->noIDs){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('id'))
					->from($dbquery->qn('#__shopping_vendor'))
					->where('alias = ' . $dbquery->q($segment));
				$db->setQuery($dbquery);
				return (int) $db->loadResult();
			}
                  
         return (int) $segment;
		}
		public function getVendorformSegment($id, $query){
			return $this->getVendorSegment($id, $query);
		}
		public function getVendorformId($segment, $query){
			return $this->getVendorId($segment, $query);
		}
		
		public function getCategoriesSegment($id, $query){
         return $this->getCategoriesSegment($id, $query);
		}
		public function getCategoriesId($segment, $query){
         return $this->getCategoriesId($segment, $query);
		}
		public function getCategorySegment($id, $query){
			if (!strpos($id, ':')){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('alias'))
					->from($dbquery->qn('#__shopping_category'))
					->where('id = ' . $dbquery->q($id));
				$db->setQuery($dbquery);
				$id .= ':' . $db->loadResult();
			}
			if ($this->noIDs){
				list($void, $segment) = explode(':', $id, 2);
				return array($void => $segment);
			}
			return array((int) $id => $id);
                  
		}
		public function getCategoryId($segment, $query){
		
			if ($this->noIDs){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('id'))
					->from($dbquery->qn('#__shopping_category'))
					->where('alias = ' . $dbquery->q($segment));
				$db->setQuery($dbquery);
				return (int) $db->loadResult();
			}
                  
         return (int) $segment;
		}
		public function getCategoryformSegment($id, $query){
			return $this->getCategorySegment($id, $query);
		}
		public function getCategoryformId($segment, $query){
			return $this->getCategoryId($segment, $query);
		}
		
		public function getProductsSegment($id, $query){
				$category = $this->getCategories(["access" => true])->get($id);
				if ($category){
					$path = array_reverse($category->getPath(), true);
					$path[0] = '0:none';
					if ($this->noIDs){
						foreach ($path as &$segment){
							list($id, $segment) = explode(':', $segment, 2);
						}
					}
					return $path;
				}
				return array();
         
		}
		public function getProductsId($segment, $query){
				if (isset($query['category'])){
					$category = $this->getCategories(["access" => true])->get($query['category']);
					if ($category){
						foreach ($category->getChildren() as $child){
							if ($this->noIDs){
								if ($child->alias == $segment){
									return $child->id;
								}
							}else{
								if ($child->id == (int) $segment){
									return $child->id;
								}
							}
						}
					}
				}
				return false;
         
		}
		public function getProductSegment($id, $query){
			if (!strpos($id, ':')){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('alias'))
					->from($dbquery->qn('#__shopping_product'))
					->where('id = ' . $dbquery->q($id));
				$db->setQuery($dbquery);
				$id .= ':' . $db->loadResult();
			}
			if ($this->noIDs){
				list($void, $segment) = explode(':', $id, 2);
				return array($void => $segment);
			}
			return array((int) $id => $id);
                  
		}
		public function getProductId($segment, $query){
		
			if ($this->noIDs){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('id'))
					->from($dbquery->qn('#__shopping_product'))
					->where('alias = ' . $dbquery->q($segment));
				$dbquery->where($dbquery->qn('category') . ' LIKE "%' . $query['category'] . '%"');
				$db->setQuery($dbquery);
				return (int) $db->loadResult();
			}
                  
         return (int) $segment;
		}
		public function getProductformSegment($id, $query){
			return $this->getProductSegment($id, $query);
		}
		public function getProductformId($segment, $query){
			return $this->getProductId($segment, $query);
		}
		
		public function getCampaignsSegment($id, $query){
         return $this->getCampaignsSegment($id, $query);
		}
		public function getCampaignsId($segment, $query){
         return $this->getCampaignsId($segment, $query);
		}
		public function getCampaignSegment($id, $query){
			if (!strpos($id, ':')){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('alias'))
					->from($dbquery->qn('#__shopping_campaign'))
					->where('id = ' . $dbquery->q($id));
				$db->setQuery($dbquery);
				$id .= ':' . $db->loadResult();
			}
			if ($this->noIDs){
				list($void, $segment) = explode(':', $id, 2);
				return array($void => $segment);
			}
			return array((int) $id => $id);
                  
		}
		public function getCampaignId($segment, $query){
		
			if ($this->noIDs){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('id'))
					->from($dbquery->qn('#__shopping_campaign'))
					->where('alias = ' . $dbquery->q($segment));
				$db->setQuery($dbquery);
				return (int) $db->loadResult();
			}
                  
         return (int) $segment;
		}
		public function getCampaignformSegment($id, $query){
			return $this->getCampaignSegment($id, $query);
		}
		public function getCampaignformId($segment, $query){
			return $this->getCampaignId($segment, $query);
		}
		
		public function getDiscountsSegment($id, $query){
         return $this->getDiscountsSegment($id, $query);
		}
		public function getDiscountsId($segment, $query){
         return $this->getDiscountsId($segment, $query);
		}
		public function getDiscountSegment($id, $query){
         return array((int) $id => $id);
		}
		public function getDiscountId($segment, $query){
		
         return (int) $segment;
		}
		public function getDiscountformSegment($id, $query){
			return $this->getDiscountSegment($id, $query);
		}
		public function getDiscountformId($segment, $query){
			return $this->getDiscountId($segment, $query);
		}
		
		public function getOrdersSegment($id, $query){
         return $this->getOrdersSegment($id, $query);
		}
		public function getOrdersId($segment, $query){
         return $this->getOrdersId($segment, $query);
		}
		public function getOrderSegment($id, $query){
         return array((int) $id => $id);
		}
		public function getOrderId($segment, $query){
		
         return (int) $segment;
		}
		public function getOrderformSegment($id, $query){
			return $this->getOrderSegment($id, $query);
		}
		public function getOrderformId($segment, $query){
			return $this->getOrderId($segment, $query);
		}
		
		public function getAddressesSegment($id, $query){
         return $this->getAddressesSegment($id, $query);
		}
		public function getAddressesId($segment, $query){
         return $this->getAddressesId($segment, $query);
		}
		public function getAddresseSegment($id, $query){
         return array((int) $id => $id);
		}
		public function getAddresseId($segment, $query){
		
         return (int) $segment;
		}
		public function getAddresseformSegment($id, $query){
			return $this->getAddresseSegment($id, $query);
		}
		public function getAddresseformId($segment, $query){
			return $this->getAddresseId($segment, $query);
		}
		
		public function getFavoritesSegment($id, $query){
         return $this->getFavoritesSegment($id, $query);
		}
		public function getFavoritesId($segment, $query){
         return $this->getFavoritesId($segment, $query);
		}
		public function getNotificationsSegment($id, $query){
         return $this->getNotificationsSegment($id, $query);
		}
		public function getNotificationsId($segment, $query){
         return $this->getNotificationsId($segment, $query);
		}
		public function getNotificationSegment($id, $query){
         return array((int) $id => $id);
		}
		public function getNotificationId($segment, $query){
		
         return (int) $segment;
		}
		public function getNotificationformSegment($id, $query){
			return $this->getNotificationSegment($id, $query);
		}
		public function getNotificationformId($segment, $query){
			return $this->getNotificationId($segment, $query);
		}
		
		public function getCompaniesSegment($id, $query){
         return $this->getCompaniesSegment($id, $query);
		}
		public function getCompaniesId($segment, $query){
         return $this->getCompaniesId($segment, $query);
		}
		public function getCompanySegment($id, $query){
			if (!strpos($id, ':')){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('alias'))
					->from($dbquery->qn('#__shopping_company'))
					->where('id = ' . $dbquery->q($id));
				$db->setQuery($dbquery);
				$id .= ':' . $db->loadResult();
			}
			if ($this->noIDs){
				list($void, $segment) = explode(':', $id, 2);
				return array($void => $segment);
			}
			return array((int) $id => $id);
                  
		}
		public function getCompanyId($segment, $query){
		
			if ($this->noIDs){
				$db = Factory::getContainer()->get('DatabaseDriver');
				$dbquery = $db->getQuery(true);
				$dbquery->select($dbquery->qn('id'))
					->from($dbquery->qn('#__shopping_company'))
					->where('alias = ' . $dbquery->q($segment));
				$db->setQuery($dbquery);
				return (int) $db->loadResult();
			}
                  
         return (int) $segment;
		}
		public function getCompanyformSegment($id, $query){
			return $this->getCompanySegment($id, $query);
		}
		public function getCompanyformId($segment, $query){
			return $this->getCompanyId($segment, $query);
		}
		
	/**
	* Method to get categories from cache
	*
	* @param	array	$options	The options for retrieving categories
	*
	* @return	CategoryInterface	The object containing categories
	*
	* @since	1.0.0
	*/
	private function getCategories(array $options = []): CategoryInterface
	{
		$key = serialize($options);
		if (!isset($this->categoryCache[$key]))
		{
			$this->categoryCache[$key] = $this->categoryFactory->createCategory($options);
		}
		return $this->categoryCache[$key];
	}
}
