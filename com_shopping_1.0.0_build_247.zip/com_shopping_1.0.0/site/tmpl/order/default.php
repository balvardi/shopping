<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	// No direct access
	defined('_JEXEC') or die;
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Language\Text;
	use \Joomla\CMS\Session\Session;
	use Joomla\Utilities\ArrayHelper;
?>
<div class="container order-content">
	<?php if ($this->params->get('show_page_heading')) : ?>
	<div class="page-header">
		<h1> <?php echo $this->escape($this->params->get('page_heading')); ?> </h1>
	</div>
	<?php endif;?>
	<div class="text-data">
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_ID'); ?></div>
			<div class="col-md-9"><?php echo $this->item->id; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_ORDERING'); ?></div>
			<div class="col-md-9"><?php echo $this->item->ordering; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_STATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->state; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_TITLE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->title; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_NUMBER'); ?></div>
			<div class="col-md-9"><?php echo $this->item->number; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_ITEMS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->items; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_TOTAL'); ?></div>
			<div class="col-md-9"><?php echo $this->item->total; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_NAME'); ?></div>
			<div class="col-md-9"><?php echo $this->item->name; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_PHONE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->phone; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_EMAIL'); ?></div>
			<div class="col-md-9"><?php echo $this->item->email; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_PROVINCE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->province; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_PRIVONCE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->privonce; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_VITY'); ?></div>
			<div class="col-md-9"><?php echo $this->item->vity; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_POSTAL_CODE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->postal_code; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_ORDER_DATE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->order_date; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_BANK_RFCODE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->bank_rfcode; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_POST_RFCODE'); ?></div>
			<div class="col-md-9"><?php echo $this->item->post_rfcode; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_PAYMENT'); ?></div>
			<div class="col-md-9"><?php echo $this->item->payment; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_USER'); ?></div>
			<div class="col-md-9"><?php echo $this->item->user; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_STATUS'); ?></div>
			<div class="col-md-9"><?php echo $this->item->status; ?></div>
		</div>
		<div class="row">
			<div class="col-md-3"><?php echo Text::_('COM_SHOPPING_FORM_LBL_ORDER_TOKEN'); ?></div>
			<div class="col-md-9"><?php echo $this->item->token; ?></div>
		</div>
	</div>
</div>