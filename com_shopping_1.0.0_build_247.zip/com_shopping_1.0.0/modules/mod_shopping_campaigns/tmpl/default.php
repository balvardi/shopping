<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
	defined('_JEXEC') or die('Restricted access');
	use \Joomla\CMS\HTML\HTMLHelper;
	use \Joomla\CMS\Factory;
	use \Joomla\CMS\Uri\Uri;
	use \Joomla\CMS\Router\Route;
	use \Joomla\CMS\Layout\LayoutHelper;
	use \Joomla\CMS\Language\Text;
	use Joomla\CMS\Session\Session;
?>
<?php if($viewtype):?>
<?php if($email):?>
<div class="container" id="module-<?php echo $module->id;?>">
		<div class="row m-0">
			<form class="contact-form validate-form col-md-6 p-4" method="post" action="">
				<h3 class="contact-form-title"><?php echo $module->title;?></h3>
				<div class="contact-form-description"><?php echo $description;?></div>
				<label class="label" for="first-name"><?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_NAME');?></label>
				<div class="wrap rs1-wrap validate-input" data-validate="<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_NAME');?>">
					<input name="name" class="form-control" type="text" name="name" placeholder="<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_NAME');?>">
				</div>
				<label class="label" for="email"><?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_EMAIL');?></label>
				<div class="wrap validate-input" data-validate = "<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_EMAIL');?>">
					<input name="email" class="form-control" type="text" name="email" placeholder="<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_EMAIL');?>">
				</div>

				<label class="label" for="phone"><?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_PHONE');?></label>
				<div class="wrap">
					<input name="phone" class="form-control" type="text" name="phone" placeholder="<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_PHONE');?>">
				</div>

				<label class="label" for="message"><?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_MESSAGE');?></label>
				<div class="wrap validate-input" data-validate = "<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_MESSAGE');?>">
					<textarea name="message" class="form-control" name="message" placeholder="<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_MESSAGE_DESC');?>"></textarea>
				</div>

				<label class="label" for="captcha"><?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_SECUROTY');?></label>
				<div class="wrap validate-input" data-validate = "<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_SECURITY');?>">
					<input name="captcha" class="form-control" type="text" name="captcha" placeholder="<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_SECURITY');?>">
				</div>

				<div class="container-form-btn">
					<button class="contact-form-btn">
						<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_SUBMIT');?>
					</button>
				</div>
			</form>

			<div class="contact-more flex-col-c-m col-md-6 p-4" style="background: url('<?php echo $backgroundphoto;?>') <?php echo $background;?>; background-size:cover;">
				<div class="flex-w size1 p-b-47">
					<div class="txt1 p-r-25">
						<span class="lnr lnr-map-marker"></span>
					</div>

					<div class="flex-col size2">
						<span class="txt1 p-b-20">
							<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_ADDERESSE');?>
						</span>

						<span class="txt2">
							<?php echo $addressee;?>
						</span>
					</div>
				</div>

				<div class="dis-flex size1 p-b-47">
					<div class="txt1 p-r-25">
						<span class="lnr lnr-phone-handset"></span>
					</div>

					<div class="flex-col size2">
						<span class="txt1 p-b-20">
							<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_PHONE');?>
						</span>

						<span class="txt3">
							<?php echo $phone;?> <?php echo $mobile;?>
						</span>
					</div>
				</div>

				<div class="dis-flex size1 p-b-47">
					<div class="txt1 p-r-25">
						<span class="lnr lnr-envelope"></span>
					</div>

					<div class="flex-col size2">
						<span class="txt1 p-b-20">
							<?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_EMAIL');?>
						</span>

						<span class="txt3">
							<a href="mailto:<?php echo $mobile;?>"><?php echo $email;?></a>
						</span>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php else:?>
<div class="container shopping-custom-module" id="module-<?php echo $module->id;?>">
	<div class="row m-0 pt-5 pb-5">
		<?php if($position=='right' or $position=='left'):?>
			<?php if($position=='left'):?>
				<div class="col-md-6 p-2">
					<div class="slogan text-primary"><?php echo $slogan;?></div>
					<h2 class="title text-primary"><?php echo $module->title;?></h2>
					<div class="description"><?php echo $description;?></div>
				</div>
				<div class="col-md-6 p-2">
					<img src="<?php echo $photo;?>" class="w-100 h-auto p-0 m-0 rounded"/>
				</div>
			<?php endif;?>
			<?php if($position=='right'):?>
				<div class="col-md-6 p-2">
					<img src="<?php echo $screenshot;?>" class="w-100 h-auto p-0 m-0 rounded"/>
				</div>
				<div class="col-md-6 p-2">
					<div class="slogan text-primary"><?php echo $slogan;?></div>
					<h2 class="title text-primary"><?php echo $module->title;?></h2>
					<div class="description"><?php echo $description;?></div>
				</div>
			<?php endif;?>
		<?php endif;?>
		<?php if($position=='center'):?>
		<div class="col-md-12 p-2">
			<img src="<?php echo $photo;?>" class="mw-100 h-auto p-0 m-0 rounded d-block m-auto"/>
		</div>
		<div class="col-md-12 p-2 text-center">
			<div class="slogan text-primary text-center"><?php echo $slogan;?></div>
			<h2 class="title text-primary text-center"><?php echo $module->title;?></h2>
			<div class="description text-center"><?php echo $description;?></div>
		</div>
		<?php endif;?>
	</div>
</div>
<?php endif;?>
<?php else:?>
	<?php if($scroll):?>
	<section class="container w-100 p-0 m-0 shopping-section shopping-view<?php echo $module->id;?> " id="module-<?php echo $module->id;?>">
		<?php if($module->showtitle):?>
		<div class="row bottom-60">
			<div class="col-12">
				<div class="heading heading-center">
					<span class="heading_pre-title"><?php echo $slogan;?></span>
					<h3 class="heading_title"><?php echo $module->title;?></h3>
					<span class="heading_layout"><?php echo $description;?></span>
				</div>
			</div>
		</div>
		<?php endif;?>
		<div class="owl-carousel owl-carousel<?php echo $module->id;?> owl-theme owl-shopping">
			<?php foreach($list as $key => $item):?>
			<div class="item">
				<article class="shopping-item item-<?php echo $item->id;?> <?php if($position=='right' or $position=='left'):?>row p-0<?php endif;?>">
					<div title="<?php echo $item->title;?>" class="shopping-link">
						<div class="photo <?php if($position=='right' or $position=='left'):?>col-md-4 p-0<?php endif;?> <?php if($caption=='true'):?>w-100<?php else:?>cover<?php endif;?>">
							<a	href="<?php echo Route::_('index.php?option=com_shopping&view=campaign&id='.(int) $item->id); ?>">
								<img src="<?php echo $item->photo;?>" class="<?php if($caption=='true'):?>w-100<?php else:?>cover-image<?php endif;?>" title="<?php echo $item->title;?>" alt="<?php echo $item->title;?>"/>
							</a>
						</div>
						<?php if($caption=='true'):?>
						<div class="content <?php if($position=='right' or $position=='left'):?>col-md-8 p-3<?php else:?>cover-text<?php endif;?>">
							<h4 class="title"><?php echo $item->title;?></h4>
							<?php if($newslead):?>
							<div class="description"><?php echo (mb_substr(strip_tags($item->description), 0, 120, 'UTF-8'));?>...</div>
							<?php endif;?>
						</div>
					<?php endif;?>
					</div>
				</article>
			</div>
			<?php endforeach;?>
		</div>
	</section>
	<script>
	jQuery('.owl-carousel<?php echo $module->id;?>').owlCarousel({
		rtl:true,
		animateIn: 'slideOutDown',
		animateOut: 'flipInX',
		margin:0,
		autoplayHoverPause:true,
		nav:true,
		smartSpeed:1000,
		responsive:{
			0:{
				items:1,
				loop:true,
				autoplay:false,
				autoplayTimeout:1000,
				nav:true

			},
			600:{
				items:<?php echo $mobile_inpage;?>,
				loop:true,
				autoplay:false,
				autoplayTimeout:1000,
				nav:true
			},
			1000:{
				items:<?php echo $desktop_inpage;?>,
				loop:true,
				autoplay:false,
				autoplayTimeout:1000,
				nav:true
			}
		}
	})
	</script>
	<?php else:?>
	<section class="container w-100 p-0 m-0 shopping-pro shopping-view<?php echo $module->id;?>	 row" id="module-<?php echo $module->id;?>">
		<?php if($module->showtitle=='1' and $position=='center'):?>
		<div class="row bottom-60">
			<div class="col-12">
				<div class="heading heading-center">
					<span class="heading_pre-title"><?php echo $slogan;?></span>
					<h3 class="heading_title"><?php echo $module->title;?></h3>
					<span class="heading_layout"><?php echo $description;?></span>
				</div>
			</div>
		</div>
		<?php endif;?>
		<?php if($module->showtitle=='1' and $position=='right'):?>
		<div class="row bottom-60 m-0 p-2 col-md-12">
			<div class="col-12">
				<div class="heading heading-center">
					<span class="heading_pre-title"><?php echo $slogan;?></span>
					<h3 class="heading_title"><?php echo $module->title;?></h3>
					<span class="heading_layout"><?php echo $description;?></span>
				</div>
			</div>
		</div>
		<?php endif;?>
		<?php if($module->showtitle=='1' and $position=='cover'):?>
		<div class="row bottom-60 m-0 p-2 col-md-12 text-center">
			<div class="col-12">
				<div class="heading heading-center">
					<span class="heading_pre-title"><?php echo $slogan;?></span>
					<h3 class="heading_title"><?php echo $module->title;?></h3>
					<span class="heading_layout"><?php echo $description;?></span>
				</div>
			</div>
		</div>
		<?php endif;?>
		<div class="row <?php if($position=='center'):?><?php else:?> m-0 p-2 col-md-12<?php endif;?>">
		<?php foreach($list as $key => $item):?>
			<article class="col-md-<?php echo (12/$inpage);?> shopping-item item-<?php echo $item->id;?> module-item-<?php echo $position;?>">
				<a href="<?php echo Route::_('index.php?option=com_shopping&view=campaign&id='.(int) $item->id); ?>" title="<?php echo $item->title;?>" class="shopping-item-link <?php if($position=='right' or $position=='left'):?>row p-0 m-0<?php endif;?>">
				<div class="photo <?php if($position=='right' or $position=='left'):?>col-md-4 p-0<?php endif;?>">
					<img src="<?php echo $item->photo;?>" class="w-100" title="<?php echo $item->title;?>" alt="<?php echo $item->title;?>"/>
				</div>
				<div class="content <?php if($position=='right' or $position=='left'):?>col-md-8 p-3<?php endif;?> item-<?php echo $item->id;?>">
					<?php if($newsdate):?>
					<div class="date muted"><?php echo $item->created_date;?></div>
					<?php endif;?>
					<h4 class="title"><?php echo $item->title;?></h4>
					<?php if($newslead):?>
					<div class="description"><?php echo (mb_substr(strip_tags($item->description), 0, 120, 'UTF-8'));?>...</div>
					<?php endif;?>
					<?php if($newsreadon):?>
					<div class="readon"><?php echo Text::_('MOD_SHOPPING_CAMPAIGNS_LABEL_READ_MORE');?></div>
					<?php endif;?>
					<?php endif;?>
				</div>
				</a>
			</article>
		<?php endforeach;?>
		</div>
		<?php if($module->showtitle=='1' and $position=='left'):?>
		<div class="row bottom-60 col-md-4">
			<div class="col-12">
				<div class="heading heading-center">
					<span class="heading_pre-title"><?php echo $slogan;?></span>
					<h3 class="heading_title"><?php echo $module->title;?></h3>
					<span class="heading_layout"><?php echo $description;?></span>
				</div>
			</div>
		</div>
		<?php endif;?>
	</section>
	<?php endif;?>
<?php endif;?>