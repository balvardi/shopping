<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Shopping\Component\Shopping\Administrator\Helper\ShoppingHelper;
/**
 * Methods supporting a list of Analyses records.
 *
 * @since	1.0.0
 */
class AnalysesModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param	array	$config	An optional associative array of configuration settings.
	*
	* @see		JController
	* @since		1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			
				'id', 'a.id',
				'user_id', 'a.user_id',
				'total_visits', 'a.total_visits',
				'most_visited_page', 'a.most_visited_page',
				'last_visit', 'a.last_visit',
			);
		}
		parent::__construct($config);
	}
	
	
	
	/**
	* Method to auto-populate the model state.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @param	string	$ordering	Elements order
	* @param	string	$direction	Order direction
	*
	* @return void
	*
	* @throws Exception
	*/
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "ASC");
		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);
			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}
	/**
	* Method to get a store id based on model configuration state.
	*
	* This is necessary because the model is used by the component and
	* different modules that might need different sets of data or different
	* ordering requirements.
	*
	* @param	string	$id	A prefix for the store id.
	*
	* @return	string A store id.
	*
	* @since	1.0.0
	*/
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}
	/**
	* Build an SQL query to load the list data.
	*
	* @return	DatabaseQuery
	*
	* @since	1.0.0
	*/
	protected function getListQuery()
	{
		// Create a new query object.
		$db	= $this->getDbo();
		$query = $db->getQuery(true);
		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__shopping_analysis` AS a');
		
		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.id LIKE ' . $search . '  OR	a.user_id LIKE ' . $search . ' OR	a.total_visits LIKE ' . $search . ' OR	a.most_visited_page LIKE ' . $search . ' OR	a.last_visit LIKE ' . $search . ')');
			}
		}
		
		// Filtering user_id
		$filter_user_id = $this->state->get("filter.user_id");
		if ($filter_user_id !== null && (is_numeric($filter_user_id) || !empty($filter_user_id)))
		{
			$query->where("a.`user_id` = '".$db->escape($filter_user_id)."'");
		}
		
		// Filtering total_visits
		$filter_total_visits = $this->state->get("filter.total_visits");
		if ($filter_total_visits !== null && (is_numeric($filter_total_visits) || !empty($filter_total_visits)))
		{
			$query->where("a.`total_visits` = '".$db->escape($filter_total_visits)."'");
		}
		
		// Filtering most_visited_page
		$filter_most_visited_page = $this->state->get("filter.most_visited_page");
		if ($filter_most_visited_page !== null && (is_numeric($filter_most_visited_page) || !empty($filter_most_visited_page)))
		{
			$query->where("a.`most_visited_page` = '".$db->escape($filter_most_visited_page)."'");
		}
		
		// Filtering last_visit
		$filter_last_visit = $this->state->get("filter.last_visit");
		if ($filter_last_visit !== null && (is_numeric($filter_last_visit) || !empty($filter_last_visit)))
		{
			$query->where("a.`last_visit` = '".$db->escape($filter_last_visit)."'");
		}
		
		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "ASC");
		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		return $query;
	}
	/**
	* Get an array of data items
	*
	* @return mixed Array of data items on success, false on failure.
	*/
	public function getItems()
	{
		$items = parent::getItems();
		foreach ($items as $oneItem)
		{
		}
		return $items;
	}
}
	