<?php
	/**
	* @version	1.0.0
	* @package	com_shopping
	* @author	R.Balvardi <info@dima.ir>
	* @copyright	Dima Software Group All Right Reserved
	* @license	GNU General Public License version 2 or later
	*/
namespace Shopping\Component\Shopping\Administrator\Model;
// No direct access.
defined('_JEXEC') or die;
use \Joomla\CMS\MVC\Model\ListModel;
use \Joomla\Component\Fields\Administrator\Helper\FieldsHelper;
use \Joomla\CMS\Factory;
use \Joomla\CMS\Language\Text;
use \Joomla\CMS\Helper\TagsHelper;
use \Joomla\Database\ParameterType;
use \Joomla\Utilities\ArrayHelper;
use Shopping\Component\Shopping\Administrator\Helper\ShoppingHelper;
/**
 * Methods supporting a list of Categories records.
 *
 * @since	1.0.0
 */
class CategoriesModel extends ListModel
{
	/**
	* Constructor.
	*
	* @param	array	$config	An optional associative array of configuration settings.
	*
	* @see		JController
	* @since		1.6
	*/
	public function __construct($config = array())
	{
		if (empty($config['filter_fields']))
		{
			$config['filter_fields'] = array(
			
				'id', 'a.id',
				'ordering', 'a.ordering',
				'state', 'a.state',
				'title', 'a.title',
				'alias', 'a.alias',
				'photo', 'a.photo',
				'parent', 'a.parent',
				'description', 'a.description',
				'hits', 'a.hits',
				'fields', 'a.fields',
				'created_date', 'a.created_date',
			);
		}
		parent::__construct($config);
	}
	
	
	
	/**
	* Method to auto-populate the model state.
	*
	* Note. Calling getState in this method will result in recursion.
	*
	* @param	string	$ordering	Elements order
	* @param	string	$direction	Order direction
	*
	* @return void
	*
	* @throws Exception
	*/
	protected function populateState($ordering = null, $direction = null)
	{
		// List state information.
		parent::populateState("a.id", "DESC");
		$context = $this->getUserStateFromRequest($this->context.'.filter.search', 'filter_search');
		$this->setState('filter.search', $context);
		// Split context into component and optional section
		if (!empty($context))
		{
			$parts = FieldsHelper::extract($context);
			if ($parts)
			{
				$this->setState('filter.component', $parts[0]);
				$this->setState('filter.section', $parts[1]);
			}
		}
	}
	/**
	* Method to get a store id based on model configuration state.
	*
	* This is necessary because the model is used by the component and
	* different modules that might need different sets of data or different
	* ordering requirements.
	*
	* @param	string	$id	A prefix for the store id.
	*
	* @return	string A store id.
	*
	* @since	1.0.0
	*/
	protected function getStoreId($id = '')
	{
		// Compile the store id.
		$id .= ':' . $this->getState('filter.search');
		$id .= ':' . $this->getState('filter.state');
		return parent::getStoreId($id);
	}
	/**
	* Build an SQL query to load the list data.
	*
	* @return	DatabaseQuery
	*
	* @since	1.0.0
	*/
	protected function getListQuery()
	{
		// Create a new query object.
		$db	= $this->getDbo();
		$query = $db->getQuery(true);
		// Select the required fields from the table.
		$query->select(
			$this->getState(
				'list.select', 'DISTINCT a.*'
			)
		);
		$query->from('`#__shopping_category` AS a');
		
		// Filter by published state
		$published = $this->getState('filter.state');
		if (is_numeric($published))
		{
			$query->where('a.state = ' . (int) $published);
		}
		elseif (empty($published))
		{
			$query->where('(a.state IN (0, 1))');
		}
		
		// Filter by search in title
		$search = $this->getState('filter.search');
		if (!empty($search))
		{
			if (stripos($search, 'id:') === 0)
			{
				$query->where('a.id = ' . (int) substr($search, 3));
			}
			else
			{
				$search = $db->Quote('%' . $db->escape($search, true) . '%');
				$query->where('( a.id LIKE ' . $search . '  OR	a.ordering LIKE ' . $search . ' OR	a.state LIKE ' . $search . ' OR	a.title LIKE ' . $search . ' OR	a.alias LIKE ' . $search . ' OR	a.photo LIKE ' . $search . ' OR	a.parent LIKE ' . $search . ' OR	a.description LIKE ' . $search . ' OR	a.hits LIKE ' . $search . ' OR	a.fields LIKE ' . $search . ' OR	a.created_date LIKE ' . $search . ')');
			}
		}
		
		// Filtering ordering
		$filter_ordering = $this->state->get("filter.ordering");
		if ($filter_ordering !== null && (is_numeric($filter_ordering) || !empty($filter_ordering)))
		{
			$query->where("a.`ordering` = '".$db->escape($filter_ordering)."'");
		}
		
		// Filtering state
		$filter_state = $this->state->get("filter.state");
		if ($filter_state !== null && (is_numeric($filter_state) || !empty($filter_state)))
		{
			$query->where("a.`state` = '".$db->escape($filter_state)."'");
		}
		
		// Filtering title
		$filter_title = $this->state->get("filter.title");
		if ($filter_title !== null && (is_numeric($filter_title) || !empty($filter_title)))
		{
			$query->where("a.`title` = '".$db->escape($filter_title)."'");
		}
		
		// Filtering alias
		$filter_alias = $this->state->get("filter.alias");
		if ($filter_alias !== null && (is_numeric($filter_alias) || !empty($filter_alias)))
		{
			$query->where("a.`alias` = '".$db->escape($filter_alias)."'");
		}
		
		// Filtering photo
		$filter_photo = $this->state->get("filter.photo");
		if ($filter_photo !== null && (is_numeric($filter_photo) || !empty($filter_photo)))
		{
			$query->where("a.`photo` = '".$db->escape($filter_photo)."'");
		}
		
		// Filtering parent
		$filter_parent = $this->state->get("filter.parent");
		if ($filter_parent !== null && (is_numeric($filter_parent) || !empty($filter_parent)))
		{
			$query->where("a.`parent` = '".$db->escape($filter_parent)."'");
		}
		
		// Filtering description
		$filter_description = $this->state->get("filter.description");
		if ($filter_description !== null && (is_numeric($filter_description) || !empty($filter_description)))
		{
			$query->where("a.`description` = '".$db->escape($filter_description)."'");
		}
		
		// Filtering hits
		$filter_hits = $this->state->get("filter.hits");
		if ($filter_hits !== null && (is_numeric($filter_hits) || !empty($filter_hits)))
		{
			$query->where("a.`hits` = '".$db->escape($filter_hits)."'");
		}
		
		// Filtering fields
		$filter_fields = $this->state->get("filter.fields");
		if ($filter_fields !== null && (is_numeric($filter_fields) || !empty($filter_fields)))
		{
			$query->where("a.`fields` = '".$db->escape($filter_fields)."'");
		}
		
		// Filtering created_date
		$filter_created_date = $this->state->get("filter.created_date");
		if ($filter_created_date !== null && (is_numeric($filter_created_date) || !empty($filter_created_date)))
		{
			$query->where("a.`created_date` = '".$db->escape($filter_created_date)."'");
		}
		
		// Add the list ordering clause.
		$orderCol	= $this->state->get('list.ordering', "a.id");
		$orderDirn = $this->state->get('list.direction', "DESC");
		if ($orderCol && $orderDirn)
		{
			$query->order($db->escape($orderCol . ' ' . $orderDirn));
		}
		return $query;
	}
	/**
	* Get an array of data items
	*
	* @return mixed Array of data items on success, false on failure.
	*/
	public function getItems()
	{
		$items = parent::getItems();
		foreach ($items as $oneItem)
		{
		}
		return $items;
	}
}
	